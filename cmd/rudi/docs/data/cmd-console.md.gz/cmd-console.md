{¤
 ¤}{¤000006: Welcome to the Rudi interpreter :) ¤}{¤

 ¤}{¤000003:You can enter one of                                                                              ¤}{¤

 ¤}{¤000004:• A path expression, like ¤}{¤000017: .foo ¤}{¤000004: or ¤}{¤000017: .foo[0].bar ¤}{¤000004: to access the global document.                  ¤}{¤
 ¤}{¤000004:• An expression like (+ .foo 42) to compute data by functions; see the topics                     ¤}{¤
 ¤}{¤000004:below or the Rudi website for a complete list of available functions.                             ¤}{¤
 ¤}{¤000004:• A scalar JSON value, like ¤}{¤000017: 3 ¤}{¤000004: or ¤}{¤000017: [1 2 3] ¤}{¤000004:, which will simply return that                       ¤}{¤
 ¤}{¤000004:exact value with no further side effects. Not super useful usually.                               ¤}{¤

 ¤}{¤000007:## Commands¤}{¤

 ¤}{¤000003:Additionally, the following commands can be used:                                                 ¤}{¤

 ¤}{¤000004:• help       – Show this help text.                                                               ¤}{¤
 ¤}{¤000004:• help TOPIC – Show help for a specific topic.                                                    ¤}{¤
 ¤}{¤000004:• exit       – Exit Rudi immediately.                                                             ¤}{¤

 ¤}{¤000007:## Help Topics¤}{¤

 ¤}{¤000003:The following topics are available and can be accessed using ¤}{¤000017: help TOPIC ¤}{¤000003::                        ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: language ¤}{¤000004: – A short introduction to the Rudi language                                          ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: coalescing ¤}{¤000004: – How Rudi handles, converts and compares values                                   ¤}{¤

 ¤}{¤000003:You can also request help for any of these functions using ¤}{¤000017: help FUNCTION ¤}{¤000003::                       ¤}{¤

 ¤}{¤000004:• ¤}{¤00000e:core¤}{¤000004:                                                                                            ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: default ¤}{¤000004: – returns the default value if the first argument is empty                          ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: delete ¤}{¤000004: – removes a key from an object or an item from a vector                              ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: do ¤}{¤000004: – eval a sequence of statements where only one expression is valid                       ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: empty? ¤}{¤000004: – returns true when the given value is empty-ish (0, false, null, "", ...)           ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: error ¤}{¤000004: – returns an error                                                                    ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: has? ¤}{¤000004: – returns true if the given symbol's path expression points to an existing value       ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: if ¤}{¤000004: – evaluate one of two expressions based on a condition                                   ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: set ¤}{¤000004: – set a value in a variable/document, only really useful with ! modifier (set!)         ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: try ¤}{¤000004: – returns the fallback if the first expression errors out                               ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:coalesce¤}{¤000004:                                                                                        ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: humanely ¤}{¤000004: – evaluates the child expressions using humane coalescing                          ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: pedantically ¤}{¤000004: – evaluates the child expressions using pedantic coalescing                    ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: strictly ¤}{¤000004: – evaluates the child expressions using strict coalescing                          ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:compare¤}{¤000004:                                                                                         ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: eq? ¤}{¤000004: – equality check: return true if both arguments are the same                            ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: gt? ¤}{¤000004: – returns a > b                                                                         ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: gte? ¤}{¤000004: – returns a >= b                                                                       ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: identical? ¤}{¤000004: – like ¤}{¤000017: eq? ¤}{¤000004:, but always uses strict coalecsing                                  ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: like? ¤}{¤000004: – like ¤}{¤000017: eq? ¤}{¤000004:, but always uses humane coalecsing                                       ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: lt? ¤}{¤000004: – returns a < b                                                                         ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: lte? ¤}{¤000004: – returns a <= b                                                                       ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:datetime¤}{¤000004:                                                                                        ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: now ¤}{¤000004: – returns the current date & time (UTC), formatted like a Go date                       ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:encoding¤}{¤000004:                                                                                        ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: from-base64 ¤}{¤000004: – decode a base64 encoded string                                                ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: from-json ¤}{¤000004: – decode a JSON string                                                            ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: to-base64 ¤}{¤000004: – apply base64 encoding to the given string                                       ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: to-json ¤}{¤000004: – encode the given value using JSON                                                 ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:hashing¤}{¤000004:                                                                                         ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: sha1 ¤}{¤000004: – return the lowercase hex representation of the SHA-1 hash                            ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: sha256 ¤}{¤000004: – return the lowercase hex representation of the SHA-256 hash                        ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: sha512 ¤}{¤000004: – return the lowercase hex representation of the SHA-512 hash                        ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:lists¤}{¤000004:                                                                                           ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: filter ¤}{¤000004: – returns a copy of a given vector/object with only those elements remaining that    ¤}{¤
 ¤}{¤000004:  satisfy a condition                                                                             ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: map ¤}{¤000004: – applies an expression to every element in a vector or object                          ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: range ¤}{¤000004: – allows to iterate (loop) over a vector or object                                    ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:logic¤}{¤000004:                                                                                           ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: and ¤}{¤000004: – returns true if all arguments are true                                                ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: not ¤}{¤000004: – negates the given argument                                                            ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: or ¤}{¤000004: – returns true if any of the arguments is true                                           ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:math¤}{¤000004:                                                                                            ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: add ¤}{¤000004: – returns the sum of all of its arguments                                               ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: div ¤}{¤000004: – returns arg1 / arg2 / .. / argN (always a floating point division, regardless of      ¤}{¤
 ¤}{¤000004:  arguments)                                                                                      ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: mult ¤}{¤000004: – returns the product of all of its arguments                                          ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: sub ¤}{¤000004: – returns arg1 - arg2 - .. - argN                                                       ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:strings¤}{¤000004:                                                                                         ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: append ¤}{¤000004: – appends more strings to a string or arbitrary items into a vector                  ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: concat ¤}{¤000004: – concatenates items in a vector using a common glue string                          ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: contains? ¤}{¤000004: – returns true if a string contains a substring or a vector contains the given    ¤}{¤
 ¤}{¤000004:  element                                                                                         ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: has-prefix? ¤}{¤000004: – returns true if the given string has the prefix                               ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: has-suffix? ¤}{¤000004: – returns true if the given string has the suffix                               ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: len ¤}{¤000004: – returns the length of a string, vector or object                                      ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: prepend ¤}{¤000004: – prepends more strings to a string or arbitrary items into a vector                ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: replace ¤}{¤000004: – returns a copy of a string with the a substring replaced by another               ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: reverse ¤}{¤000004: – reverses a string or the elements of a vector                                     ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: split ¤}{¤000004: – splits a string into a vector                                                       ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: to-lower ¤}{¤000004: – returns the lowercased version of the given string                               ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: to-upper ¤}{¤000004: – returns the uppercased version of the given string                               ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: trim ¤}{¤000004: – returns the given whitespace with leading/trailing whitespace removed                ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: trim-prefix ¤}{¤000004: – removes the prefix from the string, if it exists                              ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: trim-suffix ¤}{¤000004: – removes the suffix from the string, if it exists                              ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:types¤}{¤000004:                                                                                           ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: to-bool ¤}{¤000004: – try to convert the given argument losslessly to a bool                            ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: to-float ¤}{¤000004: – try to convert the given argument losslessly to a float64                        ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: to-int ¤}{¤000004: – try to convert the given argument losslessly to an int64                           ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: to-string ¤}{¤000004: – try to convert the given argument losslessly to a string                        ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: type-of ¤}{¤000004: – returns the type of a given value (e.g. "string" or "number")                     ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:rudifunc¤}{¤000004:                                                                                        ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: func ¤}{¤000004: – defines a new function                                                               ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:semver¤}{¤000004:                                                                                          ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: semver ¤}{¤000004: – parses a string as a semantic version                                              ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:set¤}{¤000004:                                                                                             ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: new-key-set ¤}{¤000004: – create a set filled with the keys of an object                                ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: new-set ¤}{¤000004: – create a set filled with the given values                                         ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: set-delete ¤}{¤000004: – returns a copy of the set with the given values removed from it                ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: set-diff ¤}{¤000004: – returns the difference between two sets                                          ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: set-eq? ¤}{¤000004: – returns true if two sets hold the same values                                     ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: set-has-any? ¤}{¤000004: – returns true if the set contains ¤}{¤00000d:any¤}{¤000004: of the given values                     ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: set-has? ¤}{¤000004: – returns true if the set contains ¤}{¤00000d:all¤}{¤000004: of the given values                         ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: set-insert ¤}{¤000004: – returns a copy of the set with the newly added values inserted to it           ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: set-intersection ¤}{¤000004: – returns the insersection of two sets                                     ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: set-list ¤}{¤000004: – returns a sorted vector containing the values of the set                         ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: set-size ¤}{¤000004: – returns the number of values in the set                                          ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: set-superset-of? ¤}{¤000004: – returns true if the other set is a superset of the base set              ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: set-symdiff ¤}{¤000004: – returns the symmetric difference between two sets                             ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: set-union ¤}{¤000004: – returns the union of two or more sets                                           ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:uuid¤}{¤000004:                                                                                            ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: uuidv4 ¤}{¤000004: – returns a new, randomly generated v4 UUID                                          ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:yaml¤}{¤000004:                                                                                            ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: from-yaml ¤}{¤000004: – decodes a YAML string into a Go value                                           ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: to-yaml ¤}{¤000004: – encodes the given value as YAML                                                   ¤}{¤
 ¤}{¤000004:                                                                                                  ¤}{¤

¤}