{¤
 ¤}{¤000006: Type Handling & Conversions ¤}{¤

 ¤}{¤000003:Rudi has pluggable coalescers, which is the term it uses for the component that is responsible for¤}{¤
 ¤}{¤000003:handling implicit type conversions (e.g. deciding whether ¤}{¤000017: 1 ¤}{¤000003: (integer) is the same as ¤}{¤000017: "1" ¤}{¤000003:      ¤}{¤
 ¤}{¤000003:(string)) and by extension also for equality checks between two values.                           ¤}{¤

 ¤}{¤000004:• Background                                                                                      ¤}{¤
 ¤}{¤000004:• Coalescers                                                                                      ¤}{¤
 ¤}{¤000004:  • Strict                                                                                        ¤}{¤
 ¤}{¤000004:  • Pedantic                                                                                      ¤}{¤
 ¤}{¤000004:  • Humane                                                                                        ¤}{¤
 ¤}{¤000004:• Conversion Functions                                                                            ¤}{¤
 ¤}{¤000004:• Comparisons                                                                                     ¤}{¤

 ¤}{¤000007:## Background¤}{¤

 ¤}{¤000003:Rudi programs are meant to transform data structures, often YAML/JSON files. In some cases, these ¤}{¤
 ¤}{¤000003:are based on strictly typed datastructures, like ¤}{¤000014:Kubernetes¤}{¤000003: ¤}{¤000013:https://kubernetes.io¤}{¤000003: objects that are¤}{¤
 ¤}{¤000003:based on an OpenAPI schema. Sometimes however these data structures are much more loosey goosey,  ¤}{¤
 ¤}{¤000003:like ¤}{¤000014:Helm¤}{¤000003: ¤}{¤000013:https://helm.sh/¤}{¤000003: values, where a flag like ¤}{¤000017: enabled: "false" ¤}{¤000003: would ultimately be       ¤}{¤
 ¤}{¤000003:rendered using ¤}{¤000017: --enabled={{ .enabled }} ¤}{¤000003: to ¤}{¤000017: --enabled=false ¤}{¤000003:. In these cases, types are less    ¤}{¤
 ¤}{¤000003:important than the user's actual intent.                                                          ¤}{¤

 ¤}{¤000003:The built-in functions in Rudi already contain helpers like ¤}{¤000017: to-string ¤}{¤000003: or ¤}{¤000017: to-int ¤}{¤000003: to deal with  ¤}{¤
 ¤}{¤000003:conversions, but it can be tedious to have type conversions in many places in a Rudi program, just¤}{¤
 ¤}{¤000003:to deal with untyped data.                                                                        ¤}{¤

 ¤}{¤000003:To help with this, Rudi offers a choice, both to the Rudi program author by having, as well as    ¤}{¤
 ¤}{¤000003:when embedding Rudi into other Go programs: Choose your own adventure, or, "coalescer".           ¤}{¤

 ¤}{¤000003:When running ¤}{¤000017: rudi ¤}{¤000003:, the coalescing can be changed using ¤}{¤000017: --coalesce ¤}{¤000003::                            ¤}{¤

   ¤}{¤d70000:$ rudi --coalesce humane ¤}{¤d7af00:'(+ .foo 2)'¤}{¤d70000: data.yaml                                                 ¤}{¤

 ¤}{¤000007:## Coalescers¤}{¤

 ¤}{¤000003:A coalescer is a Go interface similar to this:                                                    ¤}{¤

   ¤}{¤d700d7:type¤}{¤d70000: ¤}{¤d75fd7:Coalescer¤}{¤d70000: ¤}{¤d700d7:interface¤}{¤d70000: ¤}{¤d75faf:{¤}{¤d70000:                                                                      ¤}{¤
   ¤}{¤d70000:   ¤}{¤d787d7:ToBool¤}{¤d75faf:(¤}{¤d75fd7:val¤}{¤d70000: ¤}{¤d75fd7:any¤}{¤d75faf:)¤}{¤d70000: ¤}{¤d75faf:(¤}{¤d75f5f:bool¤}{¤d75faf:,¤}{¤d70000: ¤}{¤d75f5f:error¤}{¤d75faf:)¤}{¤d70000:                                                                ¤}{¤
   ¤}{¤d70000:   ¤}{¤d787d7:ToInt64¤}{¤d75faf:(¤}{¤d75fd7:val¤}{¤d70000: ¤}{¤d75fd7:any¤}{¤d75faf:)¤}{¤d70000: ¤}{¤d75faf:(¤}{¤d75f5f:int64¤}{¤d75faf:,¤}{¤d70000: ¤}{¤d75f5f:error¤}{¤d75faf:)¤}{¤d70000:                                                              ¤}{¤
   ¤}{¤d70000:   ¤}{¤d787d7:ToString¤}{¤d75faf:(¤}{¤d75fd7:val¤}{¤d70000: ¤}{¤d75fd7:any¤}{¤d75faf:)¤}{¤d70000: ¤}{¤d75faf:(¤}{¤d75f5f:string¤}{¤d75faf:,¤}{¤d70000: ¤}{¤d75f5f:error¤}{¤d75faf:)¤}{¤d70000:                                                            ¤}{¤
   ¤}{¤d70000:   ¤}{¤d70087:// ...                                                                                       ¤}{¤
   ¤}{¤d75faf:}¤}{¤d70000:                                                                                               ¤}{¤

 ¤}{¤000003:Its task is to handle type conversions/ensurances across all Rudi functions. When ¤}{¤000017: (add 1 2) ¤}{¤000003:     ¤}{¤
 ¤}{¤000003:wants to turn its two arguments into numbers, the coalescer is used. The coalescer decides which  ¤}{¤
 ¤}{¤000003:values of which types to convert into the desired target type.                                    ¤}{¤

 ¤}{¤000003:Rudi comes with 3 coalescers to choose from:                                                      ¤}{¤

 ¤}{¤000004:• ¤}{¤00000e:Strict¤}{¤000004: is the default. This coalescer does not allow any type conversions, except turning       ¤}{¤
 ¤}{¤000017: null ¤}{¤000004: into the empty value of any type (i.e. ¤}{¤000017: null ¤}{¤000004: can turn int ¤}{¤000017: 0 ¤}{¤000004:) and allowing to turn       ¤}{¤
 ¤}{¤000004:floating point numbers into integer numbers if no precision is lost (i.e. ¤}{¤000017: 2.0 ¤}{¤000004: can turn into ¤}{¤000017: 2¤}{¤000004:  ¤}{¤
 ¤}{¤000004:).                                                                                                ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:Pedantic¤}{¤000004: is even more strict than ¤}{¤00000e:strict¤}{¤000004: and does not allow any type conversion whatsoever.     ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:Humane¤}{¤000004: is inspired by, but less forgiving than PHP's type system. This coalescer allows much    ¤}{¤
 ¤}{¤000004:more conversions, like turning ¤}{¤000017: "2.0" ¤}{¤000004: (string) into ¤}{¤000017: 2 ¤}{¤000004: (int).                                   ¤}{¤

 ¤}{¤000003:You can of course also implement your own coalescer by implementing ¤}{¤000017: pkg/coalescing.Coalescer ¤}{¤000003:.   ¤}{¤

 ¤}{¤000008:### Strict Coalescer¤}{¤

 ¤}{¤000003:A safe default with minimal conversion support. The following list shows which values/types are   ¤}{¤
 ¤}{¤000003:allowed for each target type. The left column shows the target type, the other columns list       ¤}{¤
 ¤}{¤000003:acceptable source types                                                                           ¤}{¤

 ¤}{¤000019:          │  NULL   │ BOOL │ INT64 │ FLOAT64 │ STRING │ VECTOR │ OBJECT                           ¤}{¤
 ¤}{¤000019:──────────┼─────────┼──────┼───────┼─────────┼────────┼────────┼─────────                         ¤}{¤
 ¤}{¤000019:  null    │ ✅      │ –    │ –     │ –       │ –      │ –      │ –                                ¤}{¤
 ¤}{¤000019:  bool    │ ✅      │ ✅   │ –     │ –       │ –      │ –      │ –                                ¤}{¤
 ¤}{¤000019:  int64   │ ✅      │ –    │ ✅    │ ✅(*)   │ –      │ –      │ –                                ¤}{¤
 ¤}{¤000019:  float64 │ ✅      │ –    │ ✅    │ ✅      │ –      │ –      │ –                                ¤}{¤
 ¤}{¤000019:  string  │ ✅ ("") │ –    │ –     │ –       │ ✅     │ –      │ –                                ¤}{¤
 ¤}{¤000019:  vector  │ ✅      │ –    │ –     │ –       │ –      │ ✅     │ –                                ¤}{¤
 ¤}{¤000019:  object  │ ✅      │ –    │ –     │ –       │ –      │ –      │ ✅                               ¤}{¤

 ¤}{¤000003:\*) only if lossless (e.g. ¤}{¤000017: 2.0 ¤}{¤000003: can be turned into an int64, ¤}{¤000017: 2.1 ¤}{¤000003: cannot)                       ¤}{¤

 ¤}{¤000008:### Pedantic Coalescer¤}{¤

 ¤}{¤000003:If you really want to be super extra explicit and have strongly typed source data, maybe the      ¤}{¤
 ¤}{¤000003:pedantic coalescer is more your style.                                                            ¤}{¤

 ¤}{¤000019:          │ NULL │ BOOL │ INT64 │ FLOAT64 │ STRING │ VECTOR │ OBJECT                              ¤}{¤
 ¤}{¤000019:──────────┼──────┼──────┼───────┼─────────┼────────┼────────┼─────────                            ¤}{¤
 ¤}{¤000019:  null    │ ✅   │ –    │ –     │ –       │ –      │ –      │ –                                   ¤}{¤
 ¤}{¤000019:  bool    │ –    │ ✅   │ –     │ –       │ –      │ –      │ –                                   ¤}{¤
 ¤}{¤000019:  int64   │ –    │ –    │ ✅    │ –       │ –      │ –      │ –                                   ¤}{¤
 ¤}{¤000019:  float64 │ –    │ –    │ –     │ ✅      │ –      │ –      │ –                                   ¤}{¤
 ¤}{¤000019:  string  │ –    │ –    │ –     │ –       │ ✅     │ –      │ –                                   ¤}{¤
 ¤}{¤000019:  vector  │ –    │ –    │ –     │ –       │ –      │ ✅     │ –                                   ¤}{¤
 ¤}{¤000019:  object  │ –    │ –    │ –     │ –       │ –      │ –      │ ✅                                  ¤}{¤

 ¤}{¤000008:### Humane Coalescer¤}{¤

 ¤}{¤000003:For less-than-strongly typed data, sometimes it's easier to just accept humans for what they are and¤}{¤
 ¤}{¤000003:that ¤}{¤000017: replicas: "2" ¤}{¤000003: really meant ¤}{¤000017: replicas: 2 ¤}{¤000003:. For cases like this, use the humane coalescer,   ¤}{¤
 ¤}{¤000003:which is inspired by PHP, but a bit less flexible. Also instead of turning ¤}{¤000017: true ¤}{¤000003: into ¤}{¤000017: "1" ¤}{¤000003: like ¤}{¤
 ¤}{¤000003:in PHP, this coalescer returns ¤}{¤000017: "true" ¤}{¤000003: (and ¤}{¤000017: "false" ¤}{¤000003: for ¤}{¤000017: false ¤}{¤000003:).                              ¤}{¤

 ¤}{¤000019:          │ NULL │ BOOL │ INT64 │ FLOAT64 │ STRING │ VECTOR │ OBJECT                              ¤}{¤
 ¤}{¤000019:──────────┼──────┼──────┼───────┼─────────┼────────┼────────┼─────────                            ¤}{¤
 ¤}{¤000019:  null    │ ✅   │ ✅   │ ✅    │ ✅      │ ✅     │ ✅     │ ✅                                  ¤}{¤
 ¤}{¤000019:  bool    │ ✅   │ ✅   │ ✅    │ ✅      │ ✅     │ ✅     │ ✅                                  ¤}{¤
 ¤}{¤000019:  int64   │ ✅   │ ✅   │ ✅    │ ✅      │ ✅     │ –      │ –                                   ¤}{¤
 ¤}{¤000019:  float64 │ ✅   │ ✅   │ ✅    │ ✅      │ ✅     │ –      │ –                                   ¤}{¤
 ¤}{¤000019:  string  │ ✅   │ ✅   │ ✅    │ ✅      │ ✅     │ –      │ –                                   ¤}{¤
 ¤}{¤000019:  vector  │ ✅   │ –    │ –     │ –       │ –      │ ✅     │ ✅                                  ¤}{¤
 ¤}{¤000019:  object  │ ✅   │ –    │ –     │ –       │ –      │ ✅     │ ✅                                  ¤}{¤

 ¤}{¤000003:Let's look closer at each type's conversion logic:                                                ¤}{¤

 ¤}{¤000004:• ¤}{¤00000e:null¤}{¤000004:: All conversions to ¤}{¤000017: null ¤}{¤000004: are only allowed for the empty value of each source type        ¤}{¤
 ¤}{¤000004:(meaning that ¤}{¤000017: false ¤}{¤000004: and ¤}{¤000017: 0 ¤}{¤000004: are convertible, but ¤}{¤000017: true ¤}{¤000004: and ¤}{¤000017: "foo" ¤}{¤000004: are not).                   ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:bool¤}{¤000004:: Empty values are considered ¤}{¤000017: false ¤}{¤000004:, all others ¤}{¤000017: true ¤}{¤000004:. The string ¤}{¤000017: "0" ¤}{¤000004: and ¤}{¤000017: "false" ¤}{¤000004:    ¤}{¤
 ¤}{¤000004:are also considered ¤}{¤000017: false ¤}{¤000004:.                                                                      ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:int64¤}{¤000004:: Empty values are ¤}{¤000017: 0 ¤}{¤000004:, ¤}{¤000017: true ¤}{¤000004: becomes ¤}{¤000017: 1 ¤}{¤000004:. If lossless conversion from float64 to int64   ¤}{¤
 ¤}{¤000004:is possible, it's performed, otherwise an error is returned. Strings have their whitespace        ¤}{¤
 ¤}{¤000004:trimmed;                                                                                          ¤}{¤
 ¤}{¤000004:if the resulting string is empty, ¤}{¤000017: 0 ¤}{¤000004: is returned, otherwise the string is parsed as an integer;  ¤}{¤
 ¤}{¤000004:if not successful, parsing as float is attempted and if the resulting float can be losslessly     ¤}{¤
 ¤}{¤000004:converted, it's returned (e.g. ¤}{¤000017: "2.0" ¤}{¤000004: is valid, ¤}{¤000017: "2.1" ¤}{¤000004: is not). Otherwise an error is returned. ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:float64¤}{¤000004:: Empty values are ¤}{¤000017: 0.0 ¤}{¤000004:, ¤}{¤000017: true ¤}{¤000004: becomes ¤}{¤000017: 1.0 ¤}{¤000004:. Integers are converted to floats.        ¤}{¤
 ¤}{¤000004:Strings have their whitespace trimmed; if the resulting string is empty, ¤}{¤000017: 0.0 ¤}{¤000004: is returned,       ¤}{¤
 ¤}{¤000004:otherwise the string is parsed as a float; if not possible to parse as float, an error is         ¤}{¤
 ¤}{¤000004:returned.                                                                                         ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:string¤}{¤000004:: works as expected; floats have their trailing zeros trimmed (¤}{¤000017: 3.12000 ¤}{¤000004: becomes          ¤}{¤
 ¤}{¤000017: "3.12" ¤}{¤000004:). ¤}{¤000017: true ¤}{¤000004: becomes ¤}{¤000017: "true" ¤}{¤000004: and ¤}{¤000017: false ¤}{¤000004: becomes ¤}{¤000017: "false" ¤}{¤000004:. ¤}{¤000017: null ¤}{¤000004: becomes an empty string. ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:vector¤}{¤000004:: ¤}{¤000017: null ¤}{¤000004: turns into an empty vector and objects can only be converted to an empty vector  ¤}{¤
 ¤}{¤000004:if they are empty, otherwise an error is returned.                                                ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:object¤}{¤000004:: ¤}{¤000017: null ¤}{¤000004: turns into an empty object and vectors can only be converted to an empty object  ¤}{¤
 ¤}{¤000004:if they are empty, otherwise an error is returned.                                                ¤}{¤

 ¤}{¤000007:## Conversion Functions¤}{¤

 ¤}{¤000003:Rudi offers explicit conversion functions. These always apply the humane coalescing logic.        ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: to-int ¤}{¤000004: converts its argument to an int64 or returns an error if not possible.                 ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: to-float ¤}{¤000004: does the same for float64.                                                           ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: to-string ¤}{¤000004: does the same for strings.                                                          ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: to-bool ¤}{¤000004: does the same for booleans.                                                           ¤}{¤

 ¤}{¤000007:## Comparisons¤}{¤

 ¤}{¤000003:Rudi has 3 functions built-in to check for equality between 2 values:                             ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: eq? ¤}{¤000004: uses the current coalescer (i.e. by default, strict). If a Rudi program is configured to  ¤}{¤
 ¤}{¤000004:use humane coalescing however, this function will use that coalescing to determine equality.      ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: like? ¤}{¤000004: always uses humane coalescing.                                                          ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: identical? ¤}{¤000004: always uses strict coalescing.                                                     ¤}{¤

 ¤}{¤000003:Comparisons work by converting the two values into (hopefully) compatible types that can be       ¤}{¤
 ¤}{¤000003:compared. This is done in steps:                                                                  ¤}{¤

 ¤}{¤000004:1. If either of the arguments is ¤}{¤000017: null ¤}{¤000004:, try to convert to other to ¤}{¤000017: null ¤}{¤000004:.                       ¤}{¤
 ¤}{¤000004:2. Do the same with ¤}{¤000017: bool ¤}{¤000004:.                                                                       ¤}{¤
 ¤}{¤000004:3. Do the same with ¤}{¤000017: int64 ¤}{¤000004:.                                                                      ¤}{¤
 ¤}{¤000004:4. Do the same with ¤}{¤000017: float64 ¤}{¤000004:.                                                                    ¤}{¤
 ¤}{¤000004:5. Do the same with ¤}{¤000017: string ¤}{¤000004:.                                                                     ¤}{¤
 ¤}{¤000004:6. Do the same with ¤}{¤000017: vector ¤}{¤000004:.                                                                     ¤}{¤
 ¤}{¤000004:7. Do the same with ¤}{¤000017: object ¤}{¤000004:.                                                                     ¤}{¤

 ¤}{¤00000e:NB:¤}{¤000003: Equality rules are associative (if ¤}{¤000017: a == b ¤}{¤000003:, then ¤}{¤000017: b == a ¤}{¤000003:), but not transitive, which is     ¤}{¤
 ¤}{¤000003:especially apparent with humane coalescing:                                                       ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: " " == true ¤}{¤000004: because the string is not empty.                                                  ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: " " == 0 ¤}{¤000004: because empty strings can turn into ¤}{¤000017: 0 ¤}{¤000004:.                                             ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: 0 == false ¤}{¤000004: because both are the empty values of their types.                                  ¤}{¤

 ¤}{¤000003:If rules were transitive, ¤}{¤000017: 0 ¤}{¤000003: could not both be ¤}{¤000017: false ¤}{¤000003: and ¤}{¤000017: true ¤}{¤000003: at the same time.              ¤}{¤

¤}