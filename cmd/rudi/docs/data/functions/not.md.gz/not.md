{¤
 ¤}{¤000006: not ¤}{¤

 ¤}{¤000017: not ¤}{¤000003: negates the given value.                                                                    ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (not true) ¤}{¤000004: ➜ ¤}{¤000017: false ¤}{¤000004:                                                                          ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (not false) ¤}{¤000004: ➜ ¤}{¤000017: true ¤}{¤000004:                                                                          ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (not expr:bool) ¤}{¤000008: ➜ ¤}{¤000017: bool ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: expr ¤}{¤000004: is an arbitrary expressions.                                                             ¤}{¤

 ¤}{¤000017: not ¤}{¤000003: will evaluate the expression and error out if it errors out or its result cannot be         ¤}{¤
 ¤}{¤000003:coalesced to a boolean. Otherwise, the negated boolish value is returned.                         ¤}{¤

¤}