{¤
 ¤}{¤000006: * ¤}{¤

 ¤}{¤000017: * ¤}{¤000003: returns the product of all given arguments. Arguments must evaluate to numeric values. ¤}{¤000017: mult ¤}{¤000003: ¤}{¤
 ¤}{¤000003:is an alias for this function.                                                                    ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (* 1 2 3) ¤}{¤000004: -> ¤}{¤000017: 6 ¤}{¤000004:                                                                              ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (* 1 1.5) ¤}{¤000004: -> ¤}{¤000017: 1.5 ¤}{¤000004:                                                                            ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (* expr+) ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: expr ¤}{¤000004: is 1 or more expressions                                                                 ¤}{¤

 ¤}{¤000017: * ¤}{¤000003: evaluates each of the given expressions in sequence. If an expression returns an error, ¤}{¤000017: * ¤}{¤000003:   ¤}{¤
 ¤}{¤000003:returns that error and stops evaluating further expressions.                                      ¤}{¤

 ¤}{¤000003:All values are multiplied together and the final product is returned.                             ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: * ¤}{¤000003: uses one scope per expression, so nothing is shared (like variables) between expressions, and ¤}{¤
 ¤}{¤000003:nothing is leaking out.                                                                           ¤}{¤

¤}