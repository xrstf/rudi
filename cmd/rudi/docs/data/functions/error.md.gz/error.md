{¤
 ¤}{¤000006: error ¤}{¤

 ¤}{¤000017: error ¤}{¤000003: creates a new error and returns it, i.e. this function always "fails". Errors are         ¤}{¤
 ¤}{¤000003:constructed using Go's ¤}{¤000017: fmt.Errorf ¤}{¤000003:, so sprintf-style formatting is available.                    ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (error "invalid choice") ¤}{¤000004: ➜ error ¤}{¤000017: "invalid choice" ¤}{¤000004:                                           ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (error "too many replicas: %d" .replicas) ¤}{¤000004: ➜ error ¤}{¤000017: "too man replicas: 3" ¤}{¤000004:                     ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (error message:string) ¤}{¤000008: ➜ ¤}{¤000017: error ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: message ¤}{¤000004: is an arbitrary expression.                                                           ¤}{¤

 ¤}{¤000017: error ¤}{¤000003: evaluates the the message and coalesces it to a string. When successful, a new error with ¤}{¤
 ¤}{¤000003:the message is created and returned.                                                              ¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (error fmt:string args:any…) ¤}{¤000008: ➜ ¤}{¤000017: error ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: fmt ¤}{¤000004: is an arbitrary expression.                                                               ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: args ¤}{¤000004: are one ore more expressions.                                                            ¤}{¤

 ¤}{¤000017: error ¤}{¤000003: evaluates the the format and coalesces it to a string. When successful, it evaluates all  ¤}{¤
 ¤}{¤000003:further arguments and passes their results straight into ¤}{¤000017: fmt.Errorf ¤}{¤000003: and returns the newly       ¤}{¤
 ¤}{¤000003:created error.                                                                                    ¤}{¤

¤}