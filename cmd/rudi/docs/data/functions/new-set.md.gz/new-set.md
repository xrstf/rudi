{¤
 ¤}{¤000006: new-set ¤}{¤

 ¤}{¤000003:This function returns a new string set containing all the given values. Values are coalesced to   ¤}{¤
 ¤}{¤000003:strings, vectors are supported but only one level deep (see examples).                            ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (new-set) ¤}{¤000004: ➜ ¤}{¤000017: set{} ¤}{¤000004:                                                                           ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (new-set "test") ¤}{¤000004: ➜ ¤}{¤000017: set{"test"} ¤}{¤000004:                                                              ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (new-set "a" "b" "c" "b" "A") ¤}{¤000004: ➜ ¤}{¤000017: set{"a", "b", "c", "A"} ¤}{¤000004:                                     ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (new-set "a" ["b" "c"] "d") ¤}{¤000004: ➜ ¤}{¤000017: set{"a", "b", "c", "d"} ¤}{¤000004:                                       ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (new-set "a" ["b" "c" ["f"]] "d") ¤}{¤000004: ➜ error                                                     ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (new-set) ¤}{¤000008: ➜ ¤}{¤000017: set ¤}{¤

 ¤}{¤000003:This form returns a new, empty set.                                                               ¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (new-set value:any+) ¤}{¤000008: ➜ ¤}{¤000017: set ¤}{¤

 ¤}{¤000003:This form coalesces all values as either string or vector. Vectors are unpacked to one level deep ¤}{¤
 ¤}{¤000003:(i.e. they can contain things that coalesce into a string, but nothing else). Duplicate values can¤}{¤
 ¤}{¤000003:be given and will simply be dropped from the set.                                                 ¤}{¤

¤}