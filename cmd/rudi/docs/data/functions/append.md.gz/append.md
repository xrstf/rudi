{¤
 ¤}{¤000006: append ¤}{¤

 ¤}{¤000017: append ¤}{¤000003: adds additional items to a vector or concatenates a string at the end of another one,    ¤}{¤
 ¤}{¤000003:depending on the given arguments. See also this functions cousin, ¤}{¤000017: prepend ¤}{¤000003:.                      ¤}{¤

 ¤}{¤000017: append ¤}{¤000003: will append to a vector if the first argument coalesces to a vector; otherwise string    ¤}{¤
 ¤}{¤000003:coalescing is attempted. This means depending on the coalescer the behaviour of this function can ¤}{¤
 ¤}{¤000003:change when the first argument is neither vector nor string.                                      ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (append ["foo"] "bar" "x" 3) ¤}{¤000004: -> ¤}{¤000017: ["foo" "bar" "x" 3] ¤}{¤000004:                                         ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (append "foo" "bar" "baz") ¤}{¤000004: -> ¤}{¤000017: "foobarbaz" ¤}{¤000004:                                                   ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (append "foo" 2) ¤}{¤000004: -> ¤}{¤000017: "foo2" ¤}{¤000004: with humane coalescing, error otherwise                          ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (append 2 3 4) ¤}{¤000004: -> ¤}{¤000017: "234" ¤}{¤000004: with humane coalescing, error otherwise                             ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (append null 1) ¤}{¤000004: -> ¤}{¤000017: [1] ¤}{¤000004: because ¤}{¤000017: null ¤}{¤000004: can turn into empty vectors                           ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (append base appends+) ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: base ¤}{¤000004: is an arbitrary expression.                                                              ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: appends ¤}{¤000004: are one or more additional arbitrary expressions.                                     ¤}{¤

 ¤}{¤000017: append ¤}{¤000003: evaluates the base expression first. If the result coalesces to a vector, all further    ¤}{¤
 ¤}{¤000003:arguments will be appended to the vector. Otherwise, string coalescing is attempted. If the       ¤}{¤
 ¤}{¤000003:argument coalesces to neither, an error is returned.                                              ¤}{¤

 ¤}{¤000003:All further ¤}{¤000017: appends ¤}{¤000003: expressions are then evaluated and appended. For vectors, the types of the  ¤}{¤
 ¤}{¤000003:values does not matter, as vectors can hold any kind of data. For string append mode, each of the ¤}{¤
 ¤}{¤000003:further arguments must coalesce to strings, otherwise an error is returned.                       ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: append ¤}{¤000003: executes all expressions in their own contexts, so nothing is shared.                    ¤}{¤

¤}