{¤
 ¤}{¤000006: set-symdiff ¤}{¤

 ¤}{¤000003:This function returns a set of values which are in either of the sets, but not in their           ¤}{¤
 ¤}{¤000003:intersection.                                                                                     ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000003:All of the examples assume that ¤}{¤000017: $set ¤}{¤000003: is a set with ¤}{¤000017: {"a", "b", "c"} ¤}{¤000003:.                           ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (set-symdiff $set (new-set)) ¤}{¤000004: ➜ ¤}{¤000017: set{"a", "b", "c"} ¤}{¤000004:                                           ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set-symdiff $set (new-set "b")) ¤}{¤000004: ➜ ¤}{¤000017: set{"a", "c"} ¤}{¤000004:                                            ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set-symdiff $set (new-set "d")) ¤}{¤000004: ➜ ¤}{¤000017: set{"a", "b", "c", "d"} ¤}{¤000004:                                  ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (set-symdiff base:set other:set) ¤}{¤000008: ➜ ¤}{¤000017: set ¤}{¤

 ¤}{¤000003:This form returns a set of values which are in either of the sets, but not in their intersection. ¤}{¤

¤}