{¤
 ¤}{¤000006: set-superset-of? ¤}{¤

 ¤}{¤000003:This function returns true if the first set is a superset of the second set, meaning the first set¤}{¤
 ¤}{¤000003:contains at least all values of the second set.                                                   ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000003:All of the examples assume that ¤}{¤000017: $set ¤}{¤000003: is a set with ¤}{¤000017: {"a", "b", "c"} ¤}{¤000003:.                           ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (set-superset-of? (new-set) (new-set)) ¤}{¤000004: ➜ ¤}{¤000017: true ¤}{¤000004:                                               ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set-superset-of? $set (new-set)) ¤}{¤000004: ➜ ¤}{¤000017: true ¤}{¤000004:                                                    ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set-superset-of? $set (new-set "b")) ¤}{¤000004: ➜ ¤}{¤000017: true ¤}{¤000004:                                                ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set-superset-of? $set (new-set "d")) ¤}{¤000004: ➜ ¤}{¤000017: false ¤}{¤000004:                                               ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (set-superset-of? base:set other:set) ¤}{¤000008: ➜ ¤}{¤000017: bool ¤}{¤

 ¤}{¤000003:This form returns true if ¤}{¤000017: base ¤}{¤000003: is a superset of ¤}{¤000017: other ¤}{¤000003:.                                        ¤}{¤

¤}