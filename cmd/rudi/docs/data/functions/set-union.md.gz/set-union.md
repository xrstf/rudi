{¤
 ¤}{¤000006: set-union ¤}{¤

 ¤}{¤000003:This function returns the union of two or more sets.                                              ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000003:All of the examples assume that ¤}{¤000017: $set ¤}{¤000003: is a set with ¤}{¤000017: {"a", "b", "c"} ¤}{¤000003:.                           ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (set-union $set (new-set)) ¤}{¤000004: ➜ ¤}{¤000017: set{"a", "b", "c"} ¤}{¤000004:                                             ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set-union $set (new-set "b")) ¤}{¤000004: ➜ ¤}{¤000017: set{"a", "b", "c"} ¤}{¤000004:                                         ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set-union $set (new-set "d" "e")) ¤}{¤000004: ➜ ¤}{¤000017: set{"a", "b", "c", "d" "e"} ¤}{¤000004:                            ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (set-union base:set other:set+) ¤}{¤000008: ➜ ¤}{¤000017: set ¤}{¤

 ¤}{¤000003:This form returns a new set that contains all values that exist in any of the given sets. More    ¤}{¤
 ¤}{¤000003:than two sets may be merged into a union at the same time.                                        ¤}{¤

¤}