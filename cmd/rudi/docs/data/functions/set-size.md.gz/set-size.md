{¤
 ¤}{¤000006: set-size ¤}{¤

 ¤}{¤000003:This function returns the number of values in the given set.                                      ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (set-size (new-set "a" "b")) ¤}{¤000004: ➜ ¤}{¤000017: 2 ¤}{¤000004:                                                            ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set-size (set-delete (new-set "a") "a")) ¤}{¤000004: ➜ ¤}{¤000017: 0 ¤}{¤000004:                                               ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (set-size set:set) ¤}{¤000008: ➜ ¤}{¤000017: int ¤}{¤

 ¤}{¤000003:This form returns the number of values in the set.                                                ¤}{¤

¤}