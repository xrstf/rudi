{¤
 ¤}{¤000006: contains? ¤}{¤

 ¤}{¤000017: contains? ¤}{¤000003: returns ¤}{¤000017: true ¤}{¤000003: if the given haystack value contains the given needle value.           ¤}{¤

 ¤}{¤000017: contains? ¤}{¤000003: will first attempt to coalesce the first argument as a vector, and fallback to string ¤}{¤
 ¤}{¤000003:coalescing otherwise. This means depending on the coalescer the behaviour of this function can    ¤}{¤
 ¤}{¤000003:change when the first argument is neither vector nor string.                                      ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (contains? ["foo"] "bar") ¤}{¤000004: -> ¤}{¤000017: false ¤}{¤000004:                                                          ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (contains? "foo" "f") ¤}{¤000004: -> ¤}{¤000017: true ¤}{¤000004:                                                               ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (contains? "9000" 9) ¤}{¤000004: -> ¤}{¤000017: true ¤}{¤000004: with humane coalescing, error otherwise                        ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (contains? haystack needle) ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: haystack ¤}{¤000004: is an arbitrary expression.                                                          ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: needle ¤}{¤000004: is an arbitrary expression.                                                            ¤}{¤

 ¤}{¤000017: contains? ¤}{¤000003: evaluates the haystack expression first. If the result coalesces to a vector, the     ¤}{¤
 ¤}{¤000003:function will check if the vector contains the needle. Otherwise string coalescing is attempted   ¤}{¤
 ¤}{¤000003:and if it succeeds, the function will check if the needle is a substring of the hackstack. If the ¤}{¤
 ¤}{¤000003:haystack is neither string nor vector, an error is returned.                                      ¤}{¤

 ¤}{¤000003:For vector checks, the needle is evaluated and compared to each element of the haystack vector,   ¤}{¤
 ¤}{¤000003:using the current coalescer's equality rules. If an element was found that is equal to the needle, ¤}{¤
 ¤}{¤000017:true ¤}{¤000003: is returned, otherwise ¤}{¤000017: false ¤}{¤000003:.                                                             ¤}{¤

 ¤}{¤000003:For string checks, the needle is evaluated and coalesces to a string. If successful, the function ¤}{¤
 ¤}{¤000003:returns ¤}{¤000017: true ¤}{¤000003: if the needle string is contained in the haystack string, otherwise ¤}{¤000017: false ¤}{¤000003:.       ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: contains? ¤}{¤000003: executes all expressions in their own contexts, so nothing is shared.                 ¤}{¤

¤}