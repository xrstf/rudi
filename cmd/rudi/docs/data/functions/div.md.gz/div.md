{¤
 ¤}{¤000006: / ¤}{¤

 ¤}{¤000017: / ¤}{¤000003: returns the quotient of dividing all arguments. Arguments must evaluate to numeric values.    ¤}{¤
 ¤}{¤000017:div ¤}{¤000003: is an alias for this function.                                                               ¤}{¤

 ¤}{¤000003:To prevent ambiguity, this function always performs floating point divisions, regardless if all   ¤}{¤
 ¤}{¤000003:its arguments are integer numbers.                                                                ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (/ 9 3 2) ¤}{¤000004: ➜ ¤}{¤000017: 1.5 ¤}{¤000004: ((9.0 / 3.0) / 2.0)                                                         ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (/ 1 0) ¤}{¤000004: ➜ invalid: division by zero                                                           ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (/ expr:number…) ¤}{¤000008: ➜ ¤}{¤000017: number ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: expr ¤}{¤000004: is 1 or more expressions                                                                 ¤}{¤

 ¤}{¤000017: / ¤}{¤000003: evaluates each of the given expressions in sequence. If an expression returns an error, ¤}{¤000017: / ¤}{¤000003:   ¤}{¤
 ¤}{¤000003:returns that error and stops evaluating further expressions.                                      ¤}{¤

 ¤}{¤000003:The first value is taken as the dividend, every further value is then used as a divisor. The final¤}{¤
 ¤}{¤000003:result is then returned.                                                                          ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: / ¤}{¤000003: uses one scope per expression, so nothing is shared (like variables) between expressions, and ¤}{¤
 ¤}{¤000003:nothing is leaking out.                                                                           ¤}{¤

¤}