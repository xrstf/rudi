{¤
 ¤}{¤000006: set-diff ¤}{¤

 ¤}{¤000003:This function returns the difference between two sets.                                            ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000003:All of the examples assume that ¤}{¤000017: $set ¤}{¤000003: is a set with ¤}{¤000017: {"a", "b", "c"} ¤}{¤000003:.                           ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (set-diff $set (new-set)) ¤}{¤000004: ➜ ¤}{¤000017: set{"a", "b", "c"} ¤}{¤000004:                                              ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set-diff $set (new-set "b")) ¤}{¤000004: ➜ ¤}{¤000017: set{"a", "c"} ¤}{¤000004:                                               ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set-diff $set (new-set "d")) ¤}{¤000004: ➜ ¤}{¤000017: set{"a", "b", "c"} ¤}{¤000004:                                          ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (set-diff base:set other:set) ¤}{¤000008: ➜ ¤}{¤000017: set ¤}{¤

 ¤}{¤000003:This form returns ¤}{¤000017: base - other ¤}{¤000003:, i.a. a new set that contains all values that are not part of the ¤}{¤
 ¤}{¤000017:other ¤}{¤000003: set.                                                                                       ¤}{¤

¤}