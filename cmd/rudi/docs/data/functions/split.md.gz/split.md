{¤
 ¤}{¤000006: split ¤}{¤

 ¤}{¤000017: split ¤}{¤000003: splits a string using a separator into smaller substrings. It returns a vector of these   ¤}{¤
 ¤}{¤000003:substrings.                                                                                       ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (split "" "") ¤}{¤000004: ➜ ¤}{¤000017: [] ¤}{¤000004:                                                                          ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (split "," "") ¤}{¤000004: ➜ ¤}{¤000017: [""] ¤}{¤000004:                                                                       ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (split "," "a,b,1") ¤}{¤000004: ➜ ¤}{¤000017: ["a", "b", "1"] ¤}{¤000004:                                                       ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (split "" "hello") ¤}{¤000004: ➜ ¤}{¤000017: ["h", "e", "l", "l", "o"] ¤}{¤000004:                                              ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (split separator:string value:string) ¤}{¤000008: ➜ ¤}{¤000017: vector ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: separator ¤}{¤000004: is an arbitrary expression that evaluates to a string.                              ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: value ¤}{¤000004: is an arbitrary expression that evaluates to a string.                                  ¤}{¤

 ¤}{¤000017: split ¤}{¤000003: splits the ¤}{¤000017: value ¤}{¤000003: and returns a vector with the substrings.                              ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: split ¤}{¤000003: executes separator and vector in their own contexts, so nothing is shared.                ¤}{¤

¤}