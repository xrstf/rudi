{¤
 ¤}{¤000006: try ¤}{¤

 ¤}{¤000017: try ¤}{¤000003: is used to catch errors in expressions. It will evaluate an expression and return its return¤}{¤
 ¤}{¤000003:value, unless the expression errors out, then a fallback value is returned.                       ¤}{¤

 ¤}{¤000017: try ¤}{¤000003: is similar to ¤}{¤000017: default ¤}{¤000003:, but only returns the fallback value if an error occurs, compared to ¤}{¤
 ¤}{¤000017:default ¤}{¤000003: which tests for empty-ishness.                                                           ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (try (+ 1 2) "fallback") ¤}{¤000004: ➜ ¤}{¤000017: 3 ¤}{¤000004: (no error occurred in ¤}{¤000017: + ¤}{¤000004:)                                     ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (try (+ 1 "invalid") "fallback") ¤}{¤000004: ➜ ¤}{¤000017: "fallback" ¤}{¤000004:                                               ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (try (+ 1 "invalid") (+ "also invalid")) ¤}{¤000004: ➜ error                                              ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (try candidate:expression) ¤}{¤000008: ➜ ¤}{¤000017: any ¤}{¤

 ¤}{¤000003:This is equivalent to ¤}{¤000017: (try candidate null) ¤}{¤000003:.                                                     ¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (try candidate:expression fallback:expression) ¤}{¤000008: ➜ ¤}{¤000017: any ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: candidate ¤}{¤000004: is an arbitrary expression.                                                         ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: fallback ¤}{¤000004: is an arbitrary expression.                                                          ¤}{¤

 ¤}{¤000017: try ¤}{¤000003: evaluates the candidate expression and returns its return value upon success. However when  ¤}{¤
 ¤}{¤000003:the candidate return an error, the fallback expression is evaluated and its return value (or      ¤}{¤
 ¤}{¤000003:error) are returned.                                                                              ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: try ¤}{¤000003: executes candidate and fallback in their own scopes, so variables from either expression are¤}{¤
 ¤}{¤000003:not visible in the other and neither leak outside of ¤}{¤000017: try ¤}{¤000003:.                                       ¤}{¤

¤}