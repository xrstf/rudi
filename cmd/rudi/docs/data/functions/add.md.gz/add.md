{¤
 ¤}{¤000006: + ¤}{¤

 ¤}{¤000017: + ¤}{¤000003: sums up all provided arguments. Arguments must evaluate to numeric values. ¤}{¤000017: add ¤}{¤000003: is an alias  ¤}{¤
 ¤}{¤000003:for this function.                                                                                ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (+ 1 2 3) ¤}{¤000004: ➜ ¤}{¤000017: 6 ¤}{¤000004:                                                                               ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (+ 1 1.5) ¤}{¤000004: ➜ ¤}{¤000017: 2.5 ¤}{¤000004:                                                                             ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (+ expr:number…) ¤}{¤000008: ➜ ¤}{¤000017: number ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: expr ¤}{¤000004: is 1 or more expressions                                                                 ¤}{¤

 ¤}{¤000017: + ¤}{¤000003: evaluates each of the given expressions in sequence. If the expression evaluates to a number, ¤}{¤
 ¤}{¤000003:it is added to the total sum. If an expression returns an error, ¤}{¤000017: + ¤}{¤000003: returns that error and stops ¤}{¤
 ¤}{¤000003:evaluating further expressions.                                                                   ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: + ¤}{¤000003: uses one scope per expression, so nothing is shared (like variables) between expressions, and ¤}{¤
 ¤}{¤000003:nothing is leaking out.                                                                           ¤}{¤

¤}