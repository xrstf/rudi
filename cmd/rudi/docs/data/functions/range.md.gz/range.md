{¤
 ¤}{¤000006: range ¤}{¤

 ¤}{¤000017: range ¤}{¤000003: evaluates an expression for each element of a vector/object, effectively allowing to loop ¤}{¤
 ¤}{¤000003:over them. Note that this is not intended to actually modify the source vector/object, for those  ¤}{¤
 ¤}{¤000003:tasks ¤}{¤000017: map ¤}{¤000003: and ¤}{¤000017: filter ¤}{¤000003: should be used instead. ¤}{¤000017: range ¤}{¤000003: is less often used, especially with over ¤}{¤
 ¤}{¤000003:functions that would have side effects or to build up counters/sums.                              ¤}{¤

 ¤}{¤000017: range ¤}{¤000003: returns the value of the last evalauted expression. Note that since objects are iterated  ¤}{¤
 ¤}{¤000003:in effectively random order, one should not rely on the return value of ¤}{¤000017: range ¤}{¤000003: when ranging over ¤}{¤
 ¤}{¤000003:objects.                                                                                          ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (range ["foo" "bar"] [value] (print $value)) ¤}{¤000004: ➜ ¤}{¤000017: nil ¤}{¤000004:                                          ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (range {a "b" c "d"} [key value] (print $key)) ¤}{¤000004: ➜ ¤}{¤000017: nil ¤}{¤000004:                                        ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (range source:expression params:vector expr:expression) ¤}{¤000008: ➜ ¤}{¤000017: any ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: source ¤}{¤000004: is an arbitrary expression.                                                            ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: params ¤}{¤000004: is a vector describing the desired loop variable name(s).                              ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: expr ¤}{¤000004: is an arbitrary expression.                                                              ¤}{¤

 ¤}{¤000017: range ¤}{¤000003: evaluates the source argument and coalesces it to a vector or object, with vectors being  ¤}{¤
 ¤}{¤000003:preferred. If either of these operations fail, an error is returned. The naming vector ¤}{¤000017: params ¤}{¤000003:   ¤}{¤
 ¤}{¤000003:then allows to set the index/value (for vectors) or key/value (for objects) as variables, which   ¤}{¤
 ¤}{¤000003:can then be used in the expression ¤}{¤000017: expr ¤}{¤000003:, for example:                                           ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (range .data [v] (set! .data.users[$v] = "foo")) ¤}{¤000004:                                              ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (range .data [v] (set! $var (+ (try $var 0) 1))) ¤}{¤000004:                                              ¤}{¤

 ¤}{¤000017: params ¤}{¤000003: must be a vector containing one or two identifiers. If a single identifier is given, it's¤}{¤
 ¤}{¤000003:the variable name for the value. If two identifiers are given, the first is used for the          ¤}{¤
 ¤}{¤000003:index/key, the second is used for the value.                                                      ¤}{¤

 ¤}{¤000017: expr ¤}{¤000003: can then be any expression. Just like the other form, ¤}{¤000017: source ¤}{¤000003: is evaluated and coalesced  ¤}{¤
 ¤}{¤000003:to vector/object and the expression is then applied to each element.                              ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: range ¤}{¤000003: evaluates all expressions using a shared context, so it's possible for the expressions to ¤}{¤
 ¤}{¤000003:share variables.                                                                                  ¤}{¤

¤}