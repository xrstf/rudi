{¤
 ¤}{¤000006: set-eq? ¤}{¤

 ¤}{¤000003:This function returns true if two sets are identical, i.e. contain the exact same values.         ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000003:All of the examples assume that ¤}{¤000017: $set ¤}{¤000003: is a set with ¤}{¤000017: {"a", "b", "c"} ¤}{¤000003:.                           ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (set-eq? $set (new-set)) ¤}{¤000004: ➜ ¤}{¤000017: false ¤}{¤000004:                                                            ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set-eq? $set (new-set "b")) ¤}{¤000004: ➜ ¤}{¤000017: false ¤}{¤000004:                                                        ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set-eq? $set (new-set "a" "c" "b")) ¤}{¤000004: ➜ ¤}{¤000017: true ¤}{¤000004:                                                 ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set-eq? $set (new-set "a" "c" "b" "e")) ¤}{¤000004: ➜ ¤}{¤000017: false ¤}{¤000004:                                            ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (set-eq? base:set other:set) ¤}{¤000008: ➜ ¤}{¤000017: bool ¤}{¤

 ¤}{¤000003:This form returns true if both sets contain the same values.                                      ¤}{¤

¤}