{¤
 ¤}{¤000006: to-lower ¤}{¤

 ¤}{¤000017: to-lower ¤}{¤000003: removes a copy of a string with all uppercase characters replaced with their lowercase ¤}{¤
 ¤}{¤000003:equivalent. This function uses Go's regular strings package and so this function should not be    ¤}{¤
 ¤}{¤000003:used where Unicode characters are involved, unexpected results might happen.                      ¤}{¤

 ¤}{¤000003:See also ¤}{¤000017: to-upper ¤}{¤000003:.                                                                              ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (to-lower "FOO") ¤}{¤000004: -> ¤}{¤000017: "foo" ¤}{¤000004:                                                                   ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (to-lower string) ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: string ¤}{¤000004: is an arbitrary expression.                                                            ¤}{¤

 ¤}{¤000017: to-lower ¤}{¤000003: evaluates the first argument and coalesces the result into a string. When successful,  ¤}{¤
 ¤}{¤000003:the lowercased version of the string is returned.                                                 ¤}{¤

¤}