{¤
 ¤}{¤000006: to-bool ¤}{¤

 ¤}{¤000017: to-bool ¤}{¤000003: converts the given value to a boolean. The function always uses humane coalescing.      ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (to-bool 0) ¤}{¤000004: -> ¤}{¤000017: false ¤}{¤000004:                                                                        ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (to-bool "0") ¤}{¤000004: -> ¤}{¤000017: false ¤}{¤000004:                                                                      ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (to-bool 1) ¤}{¤000004: -> ¤}{¤000017: true ¤}{¤000004:                                                                         ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (to-bool []) ¤}{¤000004: -> ¤}{¤000017: false ¤}{¤000004:                                                                       ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (to-bool [0]) ¤}{¤000004: -> ¤}{¤000017: true ¤}{¤000004:                                                                       ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (to-bool value) ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: value ¤}{¤000004: is an arbitrary expression.                                                             ¤}{¤

 ¤}{¤000017: to-bool ¤}{¤000003: evaluates the given expression and then coalesces the result into a boolean value. See  ¤}{¤
 ¤}{¤000003:the documentation for the humane coalescer for the exact conversion rules.                        ¤}{¤

¤}