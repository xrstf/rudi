{¤
 ¤}{¤000006: set-delete ¤}{¤

 ¤}{¤000003:This function removes the given values from the set, returning a new set. For removing values in- ¤}{¤
 ¤}{¤000003:place, using ¤}{¤000017: set-delete! ¤}{¤000003:. Just like when constructing a new set with ¤}{¤000017: new-set ¤}{¤000003:, values must be  ¤}{¤
 ¤}{¤000003:either directly coalescable to strings, or be vectors that contain only strings.                  ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000003:All of the examples assume that ¤}{¤000017: $set ¤}{¤000003: is a set with ¤}{¤000017: {"a", "b", "c"} ¤}{¤000003:.                           ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (set-delete $set "a") ¤}{¤000004: ➜ ¤}{¤000017: set{"b", "c"} ¤}{¤000004:                                                       ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set-delete $set "a" ["b" "d"] "") ¤}{¤000004: ➜ ¤}{¤000017: set{"c"} ¤}{¤000004:                                               ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (set-delete set:set value:any+) ¤}{¤000008: ➜ ¤}{¤000017: set ¤}{¤

 ¤}{¤000003:This form returns a copy of the set, with all the values listed being removed from the set. Values¤}{¤
 ¤}{¤000003:that do not occur in the set are ignored.                                                         ¤}{¤

¤}