{¤
 ¤}{¤000006: new-key-set ¤}{¤

 ¤}{¤000003:This function takes an object and returns a new set that contains all the keys from the object.   ¤}{¤
 ¤}{¤000003:Duplicate keys (for badly written object literals in Rudi code) are allowed and will simply be    ¤}{¤
 ¤}{¤000003:merged into one within the set.                                                                   ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (new-key-set "test") ¤}{¤000004: ➜ ¤}{¤000017: error ¤}{¤000004:                                                                ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (new-key-set {}) ¤}{¤000004: ➜ (empty set)                                                                ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (new-key-set {a 1 b 2}) ¤}{¤000004: ➜ ¤}{¤000017: set{"a", "b"} ¤}{¤000004:                                                     ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (new-key-set {a 1 b 2 b 3}) ¤}{¤000004: ➜ ¤}{¤000017: set{"a", "b"} ¤}{¤000004:                                                 ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (new-key-set obj:object) ¤}{¤000008: ➜ ¤}{¤000017: set ¤}{¤

 ¤}{¤000003:This is the only form of this function. It coalesces the given value to an object and then lists  ¤}{¤
 ¤}{¤000003:all the keys into a set. Returns an error if the given value cannot be coalesced into an object.  ¤}{¤

¤}