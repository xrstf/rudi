{¤
 ¤}{¤000006: to-float ¤}{¤

 ¤}{¤000017: to-float ¤}{¤000003: converts the given value to a floating point number. The function always uses humane   ¤}{¤
 ¤}{¤000003:coalescing.                                                                                       ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (to-float 0) ¤}{¤000004: -> ¤}{¤000017: 0.0 ¤}{¤000004:                                                                         ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (to-float "0") ¤}{¤000004: -> ¤}{¤000017: 0.0 ¤}{¤000004:                                                                       ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (to-float 1) ¤}{¤000004: -> ¤}{¤000017: 1.0 ¤}{¤000004:                                                                         ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (to-float []) ¤}{¤000004: -> error                                                                        ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (to-float value) ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: value ¤}{¤000004: is an arbitrary expression.                                                             ¤}{¤

 ¤}{¤000017: to-float ¤}{¤000003: evaluates the given expression and then coalesces the result into a floating point     ¤}{¤
 ¤}{¤000003:value. See the documentation for the humane coalescer for the exact conversion rules.             ¤}{¤

¤}