{¤
 ¤}{¤000006: reverse ¤}{¤

 ¤}{¤000017: reverse ¤}{¤000003: returns a copy of the given string/vector with the characters/items inreverse order.    ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (reverse "abc") ¤}{¤000004: ➜ ¤}{¤000017: "cba" ¤}{¤000004:                                                                     ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (reverse [1 2 3]) ¤}{¤000004: ➜ ¤}{¤000017: [3 2 1] ¤}{¤000004:                                                                 ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (reverse source:string) ¤}{¤000008: ➜ ¤}{¤000017: string ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: source ¤}{¤000004: is an arbitrary expression.                                                            ¤}{¤

 ¤}{¤000003:Returns the reverse of the input strings, i.e. a string with the order of all bytes flipped.      ¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (reverse source:vector) ¤}{¤000008: ➜ ¤}{¤000017: vector ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: source ¤}{¤000004: is an arbitrary expression.                                                            ¤}{¤

 ¤}{¤000003:Returns a copy of the source vector with items in the opposite order of the source.               ¤}{¤

¤}