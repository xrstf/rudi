{¤
 ¤}{¤000006: reverse ¤}{¤

 ¤}{¤000017: reverse ¤}{¤000003: returns a copy of the given string/vector with the characters/items inreverse order.    ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (reverse "abc") ¤}{¤000004: -> ¤}{¤000017: "cba" ¤}{¤000004:                                                                    ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (reverse [1 2 3]) ¤}{¤000004: -> ¤}{¤000017: [3 2 1] ¤}{¤000004:                                                                ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (reverse source) ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: source ¤}{¤000004: is an arbitrary expression.                                                            ¤}{¤

 ¤}{¤000017: reverse ¤}{¤000003: evaluates the source expression. If tries to coalesce the value to string and if        ¤}{¤
 ¤}{¤000003:successful, returns a reverse of the string. If unsuccessful, it tries to coalesce to a vector and¤}{¤
 ¤}{¤000003:if successful, returns a copy of the vector with items in reverse order. Otherwise an error is    ¤}{¤
 ¤}{¤000003:returned.                                                                                         ¤}{¤

¤}