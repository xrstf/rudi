{¤
 ¤}{¤000006: gt? ¤}{¤

 ¤}{¤000017: gt? ¤}{¤000003: returns whether the first argument is numerically larger than the second.                   ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (gt? 3 2) ¤}{¤000004: -> ¤}{¤000017: true ¤}{¤000004:                                                                           ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (gt? 2.0 3) ¤}{¤000004: -> ¤}{¤000017: false ¤}{¤000004:                                                                        ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (gt? left right) ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: left ¤}{¤000004: is an arbitrary expression, except for identifiers.                                      ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: right ¤}{¤000004: is likewise an arbitrary expression, except for identifiers.                            ¤}{¤

 ¤}{¤000017: gt? ¤}{¤000003: evaluates both expressions and coalesces their results to be numbers. If either evaluation  ¤}{¤
 ¤}{¤000003:or conversion fail, an error is returned. If the two arguments are valid numbers, the result of   ¤}{¤
 ¤}{¤000017:left > right ¤}{¤000003: is returned.                                                                        ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: gt? ¤}{¤000003: executes both expressions in their own contexts, so nothing is shared.                      ¤}{¤

¤}