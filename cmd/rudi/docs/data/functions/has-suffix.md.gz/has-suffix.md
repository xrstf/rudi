{¤
 ¤}{¤000006: has-suffix? ¤}{¤

 ¤}{¤000017: has-suffix? ¤}{¤000003: checks whether a given string ends with another string.                             ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (has-suffix? "foobar" "bar") ¤}{¤000004: ➜ ¤}{¤000017: true ¤}{¤000004:                                                         ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (has-suffix? "foobar" "f") ¤}{¤000004: ➜ ¤}{¤000017: false ¤}{¤000004:                                                          ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (has-suffix? base:string suffix:string) ¤}{¤000008: ➜ ¤}{¤000017: bool ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: base ¤}{¤000004: is an arbitrary expression.                                                              ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: suffix ¤}{¤000004: is an arbitrary expression.                                                            ¤}{¤

 ¤}{¤000017: has-suffix? ¤}{¤000003: evaluates the first argument and coalesces it into a string. If successful, it      ¤}{¤
 ¤}{¤000003:evalates the suffix the same way. If both values are strings, the function returns true if ¤}{¤000017: base ¤}{¤000003: ¤}{¤
 ¤}{¤000003:ends with ¤}{¤000017: suffix ¤}{¤000003:.                                                                               ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: has-suffix? ¤}{¤000003: executes all expressions in their own contexts, so nothing is shared.               ¤}{¤

¤}