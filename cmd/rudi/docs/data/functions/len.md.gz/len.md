{¤
 ¤}{¤000006: len ¤}{¤

 ¤}{¤000017: len ¤}{¤000003: return the length of a string/vector or size of an object. The size of an object is the     ¤}{¤
 ¤}{¤000003:number of key-value pairs in it.                                                                  ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (len "") ¤}{¤000004: -> ¤}{¤000017: 0 ¤}{¤000004:                                                                               ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (len " hello ") ¤}{¤000004: -> ¤}{¤000017: 7 ¤}{¤000004:                                                                        ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (len [1 2 3]) ¤}{¤000004: -> ¤}{¤000017: 3 ¤}{¤000004:                                                                          ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (len {foo "bar" hello "world"}) ¤}{¤000004: -> ¤}{¤000017: 2 ¤}{¤000004:                                                        ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (len value) ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: value ¤}{¤000004: is an arbitrary expression.                                                             ¤}{¤

 ¤}{¤000017: len ¤}{¤000003: evaluates the value and depending on what it coalesces to, returns either the length of the ¤}{¤
 ¤}{¤000003:string, length of a vector or size of an object. If the value cannot be coalesced into a suitable ¤}{¤
 ¤}{¤000003:type, an error is returned.                                                                       ¤}{¤

¤}