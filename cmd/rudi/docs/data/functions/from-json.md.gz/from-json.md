{¤
 ¤}{¤000006: from-json ¤}{¤

 ¤}{¤000003:This function decodes a JSON string into a Go datastructure.                                      ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (from-json "{\"foo\": 23}") ¤}{¤000004: ➜ ¤}{¤000017: {"foo" 23} ¤}{¤000004:                                                    ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (from-json "true") ¤}{¤000004: ➜ ¤}{¤000017: true ¤}{¤000004:                                                                   ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (from-json markup:string) ¤}{¤000008: ➜ ¤}{¤000017: any ¤}{¤

 ¤}{¤000003:This is the only form of this function. It decodes a JSON string and returns the result. If       ¤}{¤
 ¤}{¤000003:invalid JSON is provided, an error is thrown.                                                     ¤}{¤

¤}