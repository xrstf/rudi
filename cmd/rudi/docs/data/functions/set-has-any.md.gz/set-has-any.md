{¤
 ¤}{¤000006: set-has-any? ¤}{¤

 ¤}{¤000003:This function returns true if at least one of the given values occur in the given set. See also   ¤}{¤
 ¤}{¤000017:set-has? ¤}{¤000003: for checking if ¤}{¤00000d:all¤}{¤000003: of the given values occur in the set.                               ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000003:All of the examples assume that ¤}{¤000017: $set ¤}{¤000003: is a set with ¤}{¤000017: {"a", "b", "c"} ¤}{¤000003:.                           ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (set-has-any? $set "") ¤}{¤000004: ➜ ¤}{¤000017: false ¤}{¤000004:                                                              ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set-has-any? $set "b") ¤}{¤000004: ➜ ¤}{¤000017: true ¤}{¤000004:                                                              ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set-has-any? $set "b" "c") ¤}{¤000004: ➜ ¤}{¤000017: true ¤}{¤000004:                                                          ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set-has-any? $set "b" "d") ¤}{¤000004: ➜ ¤}{¤000017: true ¤}{¤000004:                                                          ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set-has-any? $set "d" ["x" "y"]) ¤}{¤000004: ➜ ¤}{¤000017: false ¤}{¤000004:                                                   ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (set-has-any? base:set value:any+) ¤}{¤000008: ➜ ¤}{¤000017: bool ¤}{¤

 ¤}{¤000003:This form returns true if the set contains at least one of the given values.                      ¤}{¤

¤}