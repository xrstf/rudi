{¤
 ¤}{¤000006: has? ¤}{¤

 ¤}{¤000017: has? ¤}{¤000003: returns ¤}{¤000017: true ¤}{¤000003: if the given path expression is valid (regardless of the value it points    ¤}{¤
 ¤}{¤000003:to).                                                                                              ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (set! $var 42) (has? $var.foo) ¤}{¤000004: ➜ ¤}{¤000017: false ¤}{¤000004:                                                      ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set! $var {foo "bar"}) (has? $var.foo) ¤}{¤000004: ➜ ¤}{¤000017: true ¤}{¤000004:                                              ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (has? expr:expression) ¤}{¤000008: ➜ ¤}{¤000017: bool ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: expr ¤}{¤000004: is exactly 1 expression. This can be any expression that supports                        ¤}{¤
 ¤}{¤000004:path expressions (like variables, objects, vectors, tuples).                                      ¤}{¤

 ¤}{¤000003:The value of the expression is evaluated without applying the path expression at first. If this   ¤}{¤
 ¤}{¤000003:evaluation results in an error, the error is returned from ¤}{¤000017: has? ¤}{¤000003:. If the value was successfully  ¤}{¤
 ¤}{¤000003:computed, the path expression is evaluated against it. The function then returns whether the path ¤}{¤
 ¤}{¤000003:can be traversed successfully.                                                                    ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: has? ¤}{¤000003: evaluates the expression in its own scope, so variables defined in it do not leak.         ¤}{¤

¤}