{¤
 ¤}{¤000006: eq? ¤}{¤

 ¤}{¤000017: eq? ¤}{¤000003: compares two arguments for equalities. Equality is defined based on the currently active    ¤}{¤
 ¤}{¤000003:coalescer, so for example with strict coalescing, ¤}{¤000017: (eq 1 "1") ¤}{¤000003: is false, but with humane          ¤}{¤
 ¤}{¤000003:coalescing is true.                                                                               ¤}{¤

 ¤}{¤000003:See also ¤}{¤000017: like? ¤}{¤000003:, which always uses humane coalescing, and ¤}{¤000017: identical? ¤}{¤000003:, which always uses strict ¤}{¤
 ¤}{¤000003:coalescing.                                                                                       ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (eq? "" "") ¤}{¤000004: ➜ ¤}{¤000017: true ¤}{¤000004:                                                                          ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (eq? 1 2) ¤}{¤000004: ➜ ¤}{¤000017: false ¤}{¤000004:                                                                           ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (eq? (+ 1 1) 2) ¤}{¤000004: ➜ ¤}{¤000017: true ¤}{¤000004:                                                                      ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (eq? left:any right:any) ¤}{¤000008: ➜ ¤}{¤000017: bool ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: left ¤}{¤000004: is an arbitrary expression, except for identifiers.                                      ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: right ¤}{¤000004: is likewise an arbitrary expression, except for identifiers.                            ¤}{¤

 ¤}{¤000003:Both expressions are evaluated and then compared using the current coalescer. If evaluation of    ¤}{¤
 ¤}{¤000003:either of the expressions yields and error, that error is returned.                               ¤}{¤

 ¤}{¤000003:Equality is not defined for all type combinations and so ¤}{¤000017: eq? ¤}{¤000003: can, depending on the coalescer,   ¤}{¤
 ¤}{¤000003:return errors for invalid comparisons. With strict coalescing, ¤}{¤000017: (eq? true 2) ¤}{¤000003: returns an error    ¤}{¤
 ¤}{¤000003:because numbers cannot be converted to booleans. With humane coalescing, true would be returned   ¤}{¤
 ¤}{¤000003:instead and no error is generated.                                                                ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: eq? ¤}{¤000003: executes both expressions in their own contexts, so nothing is shared.                      ¤}{¤

¤}