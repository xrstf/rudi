{¤
 ¤}{¤000006: set-intersection ¤}{¤

 ¤}{¤000003:This function returns the intersection of two sets.                                               ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000003:All of the examples assume that ¤}{¤000017: $set ¤}{¤000003: is a set with ¤}{¤000017: {"a", "b", "c"} ¤}{¤000003:.                           ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (set-intersection $set (new-set)) ¤}{¤000004: ➜ ¤}{¤000017: set{} ¤}{¤000004:                                                   ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set-intersection $set (new-set "b")) ¤}{¤000004: ➜ ¤}{¤000017: set{"b"} ¤}{¤000004:                                            ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set-intersection $set (new-set "d")) ¤}{¤000004: ➜ ¤}{¤000017: set{} ¤}{¤000004:                                               ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (set-intersection base:set other:set) ¤}{¤000008: ➜ ¤}{¤000017: set ¤}{¤

 ¤}{¤000003:This form returns a new set that contains all values that exist in both sets.                     ¤}{¤

¤}