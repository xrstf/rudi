{¤
 ¤}{¤000006: prepend ¤}{¤

 ¤}{¤000017: prepend ¤}{¤000003: adds additional items to a vector or concatenates a string at the end of another one,   ¤}{¤
 ¤}{¤000003:depending on the given arguments. See also this functions cousin, ¤}{¤000017: append ¤}{¤000003:.                       ¤}{¤

 ¤}{¤000017: prepend ¤}{¤000003: will prepend to a vector if the first argument coalesces to a vector; otherwise string  ¤}{¤
 ¤}{¤000003:coalescing is attempted. This means depending on the coalescer the behaviour of this function can ¤}{¤
 ¤}{¤000003:change when the first argument is neither vector nor string.                                      ¤}{¤

 ¤}{¤000003:When prepending multiple elements, they are all prepended as a single list, not individually, so  ¤}{¤
 ¤}{¤000017:(prepend [1] 2 3) ¤}{¤000003: yields ¤}{¤000017: [2 3 1] ¤}{¤000003:, not ¤}{¤000017: [3 2 1] ¤}{¤000003:.                                               ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (prepend ["foo"] "bar" "x" 3) ¤}{¤000004: ➜ ¤}{¤000017: ["x" 3 "foo" "bar"] ¤}{¤000004:                                         ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (prepend "foo" "bar" "baz") ¤}{¤000004: ➜ ¤}{¤000017: "barbazfoo" ¤}{¤000004:                                                   ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (prepend "foo" 2) ¤}{¤000004: ➜ ¤}{¤000017: "2foo" ¤}{¤000004: with humane coalescing, error otherwise                          ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (prepend 2 3 4) ¤}{¤000004: ➜ ¤}{¤000017: "342" ¤}{¤000004: with humane coalescing, error otherwise                             ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (prepend null 1) ¤}{¤000004: ➜ ¤}{¤000017: [1] ¤}{¤000004: because ¤}{¤000017: null ¤}{¤000004: can turn into empty vectors                           ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (prepend base:vector prepends:any…) ¤}{¤000008: ➜ ¤}{¤000017: vector ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: base ¤}{¤000004: is an arbitrary expression.                                                              ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: prepends ¤}{¤000004: are one or more additional arbitrary expressions.                                    ¤}{¤

 ¤}{¤000003:If the ¤}{¤000017: base ¤}{¤000003: coalesces to a vector, all further arguments will be prepended to the vector.       ¤}{¤
 ¤}{¤000003:Additional items in the vector can be of any type. The result is a copy of the base vector with   ¤}{¤
 ¤}{¤000003:the newly added elements prepended to it.                                                         ¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (prepend base:string prepends:string…) ¤}{¤000008: ➜ ¤}{¤000017: string ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: base ¤}{¤000004: is an arbitrary expression.                                                              ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: prepends ¤}{¤000004: are one or more additional arbitrary expressions.                                    ¤}{¤

 ¤}{¤000003:If ¤}{¤000017: base ¤}{¤000003: is a string, all further ¤}{¤000017: prepends ¤}{¤000003: must also be strings. Each is added to the base     ¤}{¤
 ¤}{¤000003:string without any separator.                                                                     ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: prepend ¤}{¤000003: executes all expressions in their own contexts, so nothing is shared.                   ¤}{¤

¤}