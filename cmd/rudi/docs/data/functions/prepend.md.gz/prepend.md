{¤
 ¤}{¤000006: prepend ¤}{¤

 ¤}{¤000017: prepend ¤}{¤000003: adds additional items to a vector or concatenates a string at the end of another one,   ¤}{¤
 ¤}{¤000003:depending on the given arguments. See also this functions cousin, ¤}{¤000017: append ¤}{¤000003:.                       ¤}{¤

 ¤}{¤000017: prepend ¤}{¤000003: will prepend to a vector if the first argument coalesces to a vector; otherwise string  ¤}{¤
 ¤}{¤000003:coalescing is attempted. This means depending on the coalescer the behaviour of this function can ¤}{¤
 ¤}{¤000003:change when the first argument is neither vector nor string.                                      ¤}{¤

 ¤}{¤000003:When prepending multiple elements, they are all prepended as a single list, not individually, so  ¤}{¤
 ¤}{¤000017:(prepend [1] 2 3) ¤}{¤000003: yields ¤}{¤000017: [2 3 1] ¤}{¤000003:, not ¤}{¤000017: [3 2 1] ¤}{¤000003:.                                               ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (prepend ["foo"] "bar" "x" 3) ¤}{¤000004: -> ¤}{¤000017: ["x" 3 "foo" "bar"] ¤}{¤000004:                                        ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (prepend "foo" "bar" "baz") ¤}{¤000004: -> ¤}{¤000017: "barbazfoo" ¤}{¤000004:                                                  ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (prepend "foo" 2) ¤}{¤000004: -> ¤}{¤000017: "2foo" ¤}{¤000004: with humane coalescing, error otherwise                         ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (prepend 2 3 4) ¤}{¤000004: -> ¤}{¤000017: "342" ¤}{¤000004: with humane coalescing, error otherwise                            ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (prepend null 1) ¤}{¤000004: -> ¤}{¤000017: [1] ¤}{¤000004: because ¤}{¤000017: null ¤}{¤000004: can turn into empty vectors                          ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (prepend base prepends+) ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: base ¤}{¤000004: is an arbitrary expression.                                                              ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: prepends ¤}{¤000004: are one or more additional arbitrary expressions.                                    ¤}{¤

 ¤}{¤000017: prepend ¤}{¤000003: evaluates the base expression first. If the result coalesces to a vector, all further   ¤}{¤
 ¤}{¤000003:arguments will be prepended to the vector. Otherwise, string coalescing is attempted. If the      ¤}{¤
 ¤}{¤000003:argument coalesces to neither, an error is returned.                                              ¤}{¤

 ¤}{¤000003:All further ¤}{¤000017: prepends ¤}{¤000003: expressions are then evaluated and prepended. For vectors, the types of the¤}{¤
 ¤}{¤000003:values does not matter, as vectors can hold any kind of data. For string prepend mode, each of the¤}{¤
 ¤}{¤000003:further arguments must coalesce to strings, otherwise an error is returned.                       ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: prepend ¤}{¤000003: executes all expressions in their own contexts, so nothing is shared.                   ¤}{¤

¤}