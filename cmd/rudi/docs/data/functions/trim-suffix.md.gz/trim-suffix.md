{¤
 ¤}{¤000006: trim-suffix? ¤}{¤

 ¤}{¤000017: trim-suffix? ¤}{¤000003: checks whether a given string ends with another string and if it does, returns a   ¤}{¤
 ¤}{¤000003:copy of the string with the suffix removed. Note that this removal is done once, so removing the  ¤}{¤
 ¤}{¤000003:suffix ¤}{¤000017: "o" ¤}{¤000003: from ¤}{¤000017: "foo" ¤}{¤000003: will yield ¤}{¤000017: "fo" ¤}{¤000003:.                                                      ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (trim-suffix? "12344" "4") ¤}{¤000004: -> ¤}{¤000017: "1234" ¤}{¤000004:                                                        ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (trim-suffix? "12344" "x") ¤}{¤000004: -> ¤}{¤000017: "12344" ¤}{¤000004:                                                       ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (trim-suffix? base suffix) ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: base ¤}{¤000004: is an arbitrary expression.                                                              ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: suffix ¤}{¤000004: is an arbitrary expression.                                                            ¤}{¤

 ¤}{¤000017: trim-suffix? ¤}{¤000003: evaluates the first argument and coalesces it into a string. If successful, it     ¤}{¤
 ¤}{¤000003:evalates the suffix the same way. If both values are strings, the function checks if the base     ¤}{¤
 ¤}{¤000003:string has the suffix, and if so removes it once and returns the resulting string.                ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: trim-suffix? ¤}{¤000003: executes all expressions in their own contexts, so nothing is shared.              ¤}{¤

¤}