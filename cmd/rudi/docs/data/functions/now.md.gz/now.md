{¤
 ¤}{¤000006: now ¤}{¤

 ¤}{¤000017: now ¤}{¤000003: returns the current date&time, formatted using Go's date formatting logic (for example, a   ¤}{¤
 ¤}{¤000003:format string could be ¤}{¤000017: "2006-01-02" ¤}{¤000003:). The time using the currently configured timezone.         ¤}{¤

 ¤}{¤000003:See the ¤}{¤000014:Go documentation¤}{¤000003: ¤}{¤000013:https://pkg.go.dev/time#pkg-constants¤}{¤000003: for more information on the format ¤}{¤
 ¤}{¤000003:string syntax.                                                                                    ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (now "2006-01-02") ¤}{¤000004: ➜ ¤}{¤000017: "2024-01-01" ¤}{¤000004:                                                           ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (now format:string) ¤}{¤000008: ➜ ¤}{¤000017: string ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: format ¤}{¤000004: is an arbitrary expression.                                                            ¤}{¤

 ¤}{¤000017: now ¤}{¤000003: evaluates the format expression and coalesces the result to a string. If either of those    ¤}{¤
 ¤}{¤000003:steps fail, an error is returned. Otherwise the current date & time are formatted using the given ¤}{¤
 ¤}{¤000003:format.                                                                                           ¤}{¤

¤}