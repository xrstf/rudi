{¤
 ¤}{¤000006: set-list ¤}{¤

 ¤}{¤000003:This function returns a vector containing all the items in the set in sorted order.               ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (set-list (new-set "b" "a" "a" )) ¤}{¤000004: ➜ ¤}{¤000017: ["a" "b"] ¤}{¤000004:                                               ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (set-list set:set) ¤}{¤000008: ➜ ¤}{¤000017: vector ¤}{¤

 ¤}{¤000003:This form returns a vector containing all the items in the set in sorted order.                   ¤}{¤

¤}