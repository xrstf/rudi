{¤
 ¤}{¤000006: trim ¤}{¤

 ¤}{¤000017: trim ¤}{¤000003: removes all whitepace from the beginning and end of a string. This includes linebreaks.    ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (trim " hello\nworld ") ¤}{¤000004: ➜ ¤}{¤000017: "hello\nworld" ¤}{¤000004:                                                    ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (trim "\n") ¤}{¤000004: ➜ ¤}{¤000017: "" ¤}{¤000004:                                                                            ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (trim value:string) ¤}{¤000008: ➜ ¤}{¤000017: string ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: value ¤}{¤000004: is an arbitrary expression.                                                             ¤}{¤

 ¤}{¤000003:Returns a copy of the string with leading and trailing whitespace removed.                        ¤}{¤

¤}