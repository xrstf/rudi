{¤
 ¤}{¤000006: uuidv4 ¤}{¤

 ¤}{¤000003:This function returns a new, randomly generated UUID (version 4) when called. UUIDs are           ¤}{¤
 ¤}{¤000003:represented as lowercase hex strings in Rudi.                                                     ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (uuidv4) ¤}{¤000004: -> ¤}{¤000017: "0de626c1-5955-4303-a52b-420463386f76" ¤}{¤000004:                                          ¤}{¤

¤}