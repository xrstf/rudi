{¤
 ¤}{¤000006: concat ¤}{¤

 ¤}{¤000017: concat ¤}{¤000003: returns a string of all elements in a vector glued together with a common string, for    ¤}{¤
 ¤}{¤000003:example ¤}{¤000017: (concat "x" ["1" "2" "3"]) == "1x2x3" ¤}{¤000003:. The glue can be left empty, but must be a string.¤}{¤
 ¤}{¤000003:Only vectors are supported for concatenation.                                                     ¤}{¤

 ¤}{¤000017: concat ¤}{¤000003: accepts more than 1 value for the source of strings to concatenate, for example ¤}{¤000017: (concat¤}{¤000003: ¤}{¤
 ¤}{¤000017:"glue" "a" "b" "c") == "agluebgluec" ¤}{¤000003:. Strings are taken as they are, vectors are unpacked (not   ¤}{¤
 ¤}{¤000003:recursively) and must contain only strings.                                                       ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (concat "," ["1" "2" "3"]) ¤}{¤000004: -> ¤}{¤000017: "1,2,3" ¤}{¤000004:                                                       ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (concat "" ["1" "2" "3"]) ¤}{¤000004: -> ¤}{¤000017: "123" ¤}{¤000004:                                                          ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (concat "," []) ¤}{¤000004: -> ¤}{¤000017: "" ¤}{¤000004:                                                                       ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (concat "," "a" "b") ¤}{¤000004: -> ¤}{¤000017: "a,b" ¤}{¤000004:                                                               ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (concat "," "a" ["b" "c"] "d" [] "e") ¤}{¤000004: -> ¤}{¤000017: "a,b,c,d,e" ¤}{¤000004:                                        ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (concat "," "a" [["b"]]) ¤}{¤000004: -> invalid                                                           ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (concat glue element+) ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: glue ¤}{¤000004: is an arbitrary expression that evaluates to a string.                                   ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: element ¤}{¤000004: is 1 or more arbitrary expressions that each evaluate to a string                     ¤}{¤
 ¤}{¤000004:or a vector containing only strings.                                                              ¤}{¤

 ¤}{¤000017: concat ¤}{¤000003: combines all elements using the glue string. Each element can be either a string or a    ¤}{¤
 ¤}{¤000003:vector.                                                                                           ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: concat ¤}{¤000003: executes glue and each element in their own contexts, so nothing is shared.              ¤}{¤

¤}