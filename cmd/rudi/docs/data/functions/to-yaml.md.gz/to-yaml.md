{¤
 ¤}{¤000006: to-yaml ¤}{¤

 ¤}{¤000003:This function encodes a value as YAML.                                                            ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (to-yaml {foo 23}) ¤}{¤000004: ➜ ¤}{¤000017: "foo: 23\n" ¤}{¤000004:                                                            ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (to-yaml null) ¤}{¤000004: ➜ ¤}{¤000017: "null\n" ¤}{¤000004:                                                                   ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (to-yaml value:any) ¤}{¤000008: ➜ ¤}{¤000017: string ¤}{¤

 ¤}{¤000003:This is the only form of this function. It encodes a value as YAML. If encoding fails, an error is¤}{¤
 ¤}{¤000003:thrown.                                                                                           ¤}{¤

¤}