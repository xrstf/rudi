{¤
 ¤}{¤000006: or ¤}{¤

 ¤}{¤000017: or ¤}{¤000003: returns the logical disjunction of all given arguments (i.e. ¤}{¤000017: a || b || c || … ¤}{¤000003:). Each of the¤}{¤
 ¤}{¤000003:arguments must be convertible to booleans.                                                        ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (or false false) ¤}{¤000004: -> ¤}{¤000017: false ¤}{¤000004:                                                                   ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (or false false true) ¤}{¤000004: -> ¤}{¤000017: true ¤}{¤000004:                                                               ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (or expr+) ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: expr ¤}{¤000004: is one or more arbitrary expressions.                                                    ¤}{¤

 ¤}{¤000017: or ¤}{¤000003: will evaluate each expression in order, stopping at the first that either errors out or is   ¤}{¤
 ¤}{¤000003:coalesced to ¤}{¤000017: true ¤}{¤000003:. If coalescing is not possible (e.g. when using strict mode, ¤}{¤000017: (or 1) ¤}{¤000003: is      ¤}{¤
 ¤}{¤000003:invalid), an error is returned.                                                                   ¤}{¤

 ¤}{¤000003:At least one of the expressions must coalesce to ¤}{¤000017: true ¤}{¤000003: for the function to return ¤}{¤000017: true ¤}{¤000003:.        ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: or ¤}{¤000003: executes all expressions in their own contexts, so nothing is shared.                        ¤}{¤

¤}