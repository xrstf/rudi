{¤
 ¤}{¤000006: if ¤}{¤

 ¤}{¤000017: if ¤}{¤000003: allows to form conditions. It supports evaluating one expression if another is true, and     ¤}{¤
 ¤}{¤000003:allows to optionally evaluate another expression if the condition was false.                      ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (if true 42) ¤}{¤000004: -> ¤}{¤000017: 42 ¤}{¤000004:                                                                          ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (if false 42) ¤}{¤000004: -> ¤}{¤000017: null ¤}{¤000004:                                                                       ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (if true "yes" "no") ¤}{¤000004: -> ¤}{¤000017: "yes" ¤}{¤000004:                                                               ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (if false "yes" "no") ¤}{¤000004: -> ¤}{¤000017: "no" ¤}{¤000004:                                                               ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (if (gt? 4 2) "yes" "no") ¤}{¤000004: -> ¤}{¤000017: "yes" ¤}{¤000004:                                                          ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (if condition expr) ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: condition ¤}{¤000004: is any expression that evaluates to a bool.                                         ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: expr ¤}{¤000004: is any expression.                                                                       ¤}{¤

 ¤}{¤000017: if ¤}{¤000003: evaluates the condition and if it returns ¤}{¤000017: true ¤}{¤000003:, the expression is evaluated and its return ¤}{¤
 ¤}{¤000003:value is the final return value of ¤}{¤000017: if ¤}{¤000003:. If the condition is ¤}{¤000017: false ¤}{¤000003:, ¤}{¤000017: if ¤}{¤000003: returns ¤}{¤000017: null ¤}{¤000003:.        ¤}{¤

 ¤}{¤000003:If the condition or expression return an error, ¤}{¤000017: if ¤}{¤000003: returns that error.                          ¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (if condition expr-a expr-b) ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: condition ¤}{¤000004: is any expression that evaluates to a bool.                                         ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: expr-a ¤}{¤000004: is any expression.                                                                     ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: expr-b ¤}{¤000004: is any expression.                                                                     ¤}{¤

 ¤}{¤000017: if ¤}{¤000003: evaluates the condition and if it returns ¤}{¤000017: true ¤}{¤000003:, the ¤}{¤000017: expr-a ¤}{¤000003: is evaluated and its return   ¤}{¤
 ¤}{¤000003:value is the final return value of ¤}{¤000017: if ¤}{¤000003:. If the condition is ¤}{¤000017: false ¤}{¤000003:, ¤}{¤000017: if ¤}{¤000003: evaluates and returns  ¤}{¤
 ¤}{¤000017:expr-b ¤}{¤000003:.                                                                                          ¤}{¤

 ¤}{¤000017: if ¤}{¤000003: guarantees that only one of ¤}{¤000017: expr-a ¤}{¤000003: and ¤}{¤000017: expr-b ¤}{¤000003: is ever evaluated, as expressions in Rudi can¤}{¤
 ¤}{¤000003:have side effects on the global document.                                                         ¤}{¤

 ¤}{¤000003:If ¤}{¤000017: condition ¤}{¤000003:, ¤}{¤000017: expr-a ¤}{¤000003: or ¤}{¤000017: expr-b ¤}{¤000003: return an error, ¤}{¤000017: if ¤}{¤000003: returns that error.                    ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: if ¤}{¤000003: evaluates all expressions as their own scopes, so if ¤}{¤000017: condition ¤}{¤000003: sets a variable, this       ¤}{¤
 ¤}{¤000003:variable is not available in either of the positive / negative expressions.                       ¤}{¤

¤}