{¤
 ¤}{¤000006: set ¤}{¤

 ¤}{¤000017: set ¤}{¤000003: is used to define variables and to update values of variables or the global document.       ¤}{¤
 ¤}{¤000003:Similar to ¤}{¤000017: delete ¤}{¤000003: it is most often used with the bang modifier (¤}{¤000017: (set! …) ¤}{¤000003:), as modifications   ¤}{¤
 ¤}{¤000003:"do not stick" otherwise. However ¤}{¤000017: set ¤}{¤000003: can also be used to modify a datastructure "in transit",  ¤}{¤
 ¤}{¤000003:like in ¤}{¤000017: (set! .user.settings (set $defaultSettings.isAdmin false)) ¤}{¤000003:, where the inner function    ¤}{¤
 ¤}{¤000003:will change a subfield (¤}{¤000017: isAdmin ¤}{¤000003:) but still return the entire default settings object.           ¤}{¤

 ¤}{¤000017: set ¤}{¤000003: allows both overwriting the entire target value (¤}{¤000017: (set! $var …) ¤}{¤000003: or ¤}{¤000017: (set! . …) ¤}{¤000003:) as well as¤}{¤
 ¤}{¤000003:setting just a sub element (for example ¤}{¤000017: (set! .foo[0] "new-value") ¤}{¤000003:).                            ¤}{¤

 ¤}{¤000003:Variables defined by ¤}{¤000017: set ¤}{¤000003: are scoped and only valid for all following sibling expressions, never ¤}{¤
 ¤}{¤000003:the parent. For for example ¤}{¤000017: (if true (set! $x 42)) $x ¤}{¤000003: is invalid, as ¤}{¤000017: $x ¤}{¤000003: only exists in the    ¤}{¤
 ¤}{¤000003:positive branch of that ¤}{¤000017: if ¤}{¤000003: tuple.                                                               ¤}{¤

 ¤}{¤000017: set ¤}{¤000003: returns the entire target data structure, as if no path expression was given. For example in ¤}{¤
 ¤}{¤000017:(set (read-config).isAdmin false) ¤}{¤000003:, the entire configuration would be returned, not just ¤}{¤000017: false ¤}{¤000003:. ¤}{¤
 ¤}{¤000003:This is slightly different semantics from most other functions, which would return only the       ¤}{¤
 ¤}{¤000003:resulting value (e.g. ¤}{¤000017: (append $foo.list 2) ¤}{¤000003: would not return the entire ¤}{¤000017: $foo ¤}{¤000003: variable, but only¤}{¤
 ¤}{¤000003:the ¤}{¤000017: list ¤}{¤000003: vector). In that sense, ¤}{¤000017: set ¤}{¤000003: works like ¤}{¤000017: delete ¤}{¤000003:, which returns the ¤}{¤00000d:remaining¤}{¤000003: data,   ¤}{¤
 ¤}{¤000003:not whatever was removed.                                                                         ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (set! $foo 42) ¤}{¤000004: ➜ ¤}{¤000017: 42 ¤}{¤000004:                                                                         ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set! $foo 42) $foo ¤}{¤000004: ➜ ¤}{¤000017: 42 ¤}{¤000004:                                                                    ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set! .global[0].document "new-value") ¤}{¤000004: ➜ ¤}{¤000017: "new-value" ¤}{¤000004:                                        ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (set! $config {a "yes" b "yes"}) (set $config.a "no") ¤}{¤000004: ➜ ¤}{¤000017: {a "yes" b "no"} ¤}{¤000004:                    ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (set target:pathed value:any) ¤}{¤000008: ➜ ¤}{¤000017: any ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: target ¤}{¤000004: is any expression that can have a path expression.                                     ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: value ¤}{¤000004: is any expression.                                                                      ¤}{¤

 ¤}{¤000017: set ¤}{¤000003: evaluates the ¤}{¤000017: value ¤}{¤000003: and then the path expression of ¤}{¤000017: target ¤}{¤000003:. If both were successfully   ¤}{¤
 ¤}{¤000003:evaluated, the value is inserted into the target value at the given path and then the entire      ¤}{¤
 ¤}{¤000003:target is returned.                                                                               ¤}{¤

 ¤}{¤000003:Note that for variables, the path expression can be empty (e.g. ¤}{¤000017: (set $foo 42) ¤}{¤000003:). For all other   ¤}{¤
 ¤}{¤000003:valid targets, a path expression must be set (e.g. ¤}{¤000017: (set (read-config).field 42) ¤}{¤000003:) because there is¤}{¤
 ¤}{¤000003:no source that could be overwritten (like with a variable or the global document).                ¤}{¤

 ¤}{¤000003:Also note that without the bang modifier, all of variable and document changes are only returned, ¤}{¤
 ¤}{¤000003:the underlying value is not modified in-place.                                                    ¤}{¤

 ¤}{¤000017: set! ¤}{¤000003: can only be used with variables and bare path expressions (i.e. the global document),      ¤}{¤
 ¤}{¤000003:because there is no logical way to modify the result of a function call in-place.                 ¤}{¤

¤}