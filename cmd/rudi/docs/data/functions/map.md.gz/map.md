{¤
 ¤}{¤000006: map ¤}{¤

 ¤}{¤000017: map ¤}{¤000003: creates a copy of the given vector/object and then applies a function/expression to every   ¤}{¤
 ¤}{¤000003:element in that copy.                                                                             ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (map ["foo" "bar"] to-upper) ¤}{¤000004: ➜ ¤}{¤000017: ["FOO" "BAR"] ¤}{¤000004:                                                ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (map [1 2 3] [v] (+ $v 3)) ¤}{¤000004: ➜ ¤}{¤000017: [4 5 6] ¤}{¤000004:                                                        ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (map ["a" "b" "c" "d"] [idx v] $idx) ¤}{¤000004: ➜ ¤}{¤000017: [0 1 2 3] ¤}{¤000004:                                            ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (map source:expression func:identifier) ¤}{¤000008: ➜ ¤}{¤000017: any ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: source ¤}{¤000004: is an arbitrary expression.                                                            ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: func ¤}{¤000004: is a function identifier.                                                                ¤}{¤

 ¤}{¤000017: map ¤}{¤000003: evaluates the source argument and coalesces it to a vector or object, with vectors being    ¤}{¤
 ¤}{¤000003:preferred. If either of these operations fail, an error is returned. Afterwards ¤}{¤000017: map ¤}{¤000003: will replace¤}{¤
 ¤}{¤000003:the value of each item with the result of applying the function ¤}{¤000017: func ¤}{¤000003: to it.                     ¤}{¤

 ¤}{¤000017: func ¤}{¤000003: must be a function that allows being called with exactly 1 argument. If more arguments are ¤}{¤
 ¤}{¤000003:needed, use the other form of ¤}{¤000017: map ¤}{¤000003:.                                                              ¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (map source:expression params:vector expr:expression) ¤}{¤000008: ➜ ¤}{¤000017: any ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: source ¤}{¤000004: is an arbitrary expression.                                                            ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: params ¤}{¤000004: is a vector describing the desired loop variable name(s).                              ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: expr ¤}{¤000004: is an arbitrary expression.                                                              ¤}{¤

 ¤}{¤000003:When evaluating more complex conditions, this form can be used. Instead of anonymously applying a ¤}{¤
 ¤}{¤000003:function to each argument, this form allows to set the index/value (for vectors) or key/value (for¤}{¤
 ¤}{¤000003:objects) as variables, which can then be used in arbitrary expressions, for example:              ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (map .data [v] (+ $v 3)) ¤}{¤000004:                                                                      ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (map .data [idx v] $idx) ¤}{¤000004:                                                                      ¤}{¤

 ¤}{¤000017: params ¤}{¤000003: must be a vector containing one or two identifiers. If a single identifier is given, it's¤}{¤
 ¤}{¤000003:the variable name for the value. If two identifiers are given, the first is used for the          ¤}{¤
 ¤}{¤000003:index/key, the second is used for the value.                                                      ¤}{¤

 ¤}{¤000017: expr ¤}{¤000003: can then be any expression. Just like the other form, ¤}{¤000017: source ¤}{¤000003: is evaluated and coalesced  ¤}{¤
 ¤}{¤000003:to vector/object and the expression is then applied to each element.                              ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: map ¤}{¤000003: evaluates all expressions using a shared context, so it's possible for the map functions to ¤}{¤
 ¤}{¤000003:share variables.                                                                                  ¤}{¤

¤}