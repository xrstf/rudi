{¤
 ¤}{¤000006: identical? ¤}{¤

 ¤}{¤000017: identical? ¤}{¤000003: compares two arguments for equalities. Equality is defined using the strict          ¤}{¤
 ¤}{¤000003:coalescer, so ¤}{¤000017: (identical? 1 "1") ¤}{¤000003: yields a type error because strings cannot be converted to     ¤}{¤
 ¤}{¤000003:numbers.                                                                                          ¤}{¤

 ¤}{¤000003:See also ¤}{¤000017: eq? ¤}{¤000003:, which uses the currently selected coalescer, and ¤}{¤000017: like? ¤}{¤000003:, which always uses humane¤}{¤
 ¤}{¤000003:coalescing.                                                                                       ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (identical? 1 "1") ¤}{¤000004: -> ¤}{¤000017: false ¤}{¤000004:                                                                 ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (identical? 1 1.0) ¤}{¤000004: -> ¤}{¤000017: true ¤}{¤000004:                                                                  ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (identical? left right) ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: left ¤}{¤000004: is an arbitrary expression, except for identifiers.                                      ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: right ¤}{¤000004: is likewise an arbitrary expression, except for identifiers.                            ¤}{¤

 ¤}{¤000003:Both expressions are evaluated and then compared using the current coalescer. If evaluation of    ¤}{¤
 ¤}{¤000003:either of the expressions yields and error, that error is returned.                               ¤}{¤

 ¤}{¤000003:Equality is not defined for all type combinations and so ¤}{¤000017: identical? ¤}{¤000003: can return errors for       ¤}{¤
 ¤}{¤000003:invalid comparisons. See the coalescing documentation for conversion rules.                       ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: identical? ¤}{¤000003: executes both expressions in their own contexts, so nothing is shared.               ¤}{¤

¤}