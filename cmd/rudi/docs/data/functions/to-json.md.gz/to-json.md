{¤
 ¤}{¤000006: to-json ¤}{¤

 ¤}{¤000003:This function encodes a value as JSON.                                                            ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (to-json {foo 23}) ¤}{¤000004: ➜ ¤}{¤000017: "{\"foo\":23}" ¤}{¤000004:                                                         ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (to-json null) ¤}{¤000004: ➜ ¤}{¤000017: "null" ¤}{¤000004:                                                                     ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (to-json value:any) ¤}{¤000008: ➜ ¤}{¤000017: string ¤}{¤

 ¤}{¤000003:This is the only form of this function. It encodes a value as JSON. If encoding fails, an error is¤}{¤
 ¤}{¤000003:thrown.                                                                                           ¤}{¤

¤}