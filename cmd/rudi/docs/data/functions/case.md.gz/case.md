{¤
 ¤}{¤000006: case ¤}{¤

 ¤}{¤000017: case ¤}{¤000003: implements the common switch/case pattern: The function expects an even number of          ¤}{¤
 ¤}{¤000003:expressions and will sequentially process them in pairs. If the first expression yields ¤}{¤000017: true ¤}{¤000003:,   ¤}{¤
 ¤}{¤000017:case ¤}{¤000003: will return the second expression. Otherwise the next pair is checked. If none of the pairs ¤}{¤
 ¤}{¤000003:match, ¤}{¤000017: case ¤}{¤000003: returns ¤}{¤000017: null ¤}{¤000003:.                                                                     ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (case true 1 false) ¤}{¤000004: ➜ invalid                                                                 ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (case true 1 false 2) ¤}{¤000004: ➜ ¤}{¤000017: 1 ¤}{¤000004:                                                                   ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (case false 1 true 2) ¤}{¤000004: ➜ ¤}{¤000017: 2 ¤}{¤000004:                                                                   ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (case false 1 (eq? 1 2) 2) ¤}{¤000004: ➜ ¤}{¤000017: null ¤}{¤000004:                                                           ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (case exprs:expression…) ¤}{¤000008: ➜ ¤}{¤000017: any ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: exprs ¤}{¤000004: is an even number of expressions.                                                       ¤}{¤

¤}