{¤
 ¤}{¤000006: filter ¤}{¤

 ¤}{¤000017: filter ¤}{¤000003: returns a subset of the given vector/object, with elements filtered by an expression.    ¤}{¤
 ¤}{¤000003:Only those items for which the given condition expression is ¤}{¤000017: true ¤}{¤000003: will be in the resulting      ¤}{¤
 ¤}{¤000003:vector/object.                                                                                    ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (filter [0 "foo" ""] empty?) ¤}{¤000004: ➜ ¤}{¤000017: [0 ""] ¤}{¤000004:                                                       ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (filter [0 "foo" ""] [v] (not (empty? $v))) ¤}{¤000004: ➜ ¤}{¤000017: ["foo"] ¤}{¤000004:                                       ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (filter ["a" "b" "c" "d"] [idx v] (gt? $idx 1)) ¤}{¤000004: ➜ ¤}{¤000017: ["c" "d"] ¤}{¤000004:                                 ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (filter source:expression func:identifier) ¤}{¤000008: ➜ ¤}{¤000017: any ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: source ¤}{¤000004: is an arbitrary expression.                                                            ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: func ¤}{¤000004: is a function identifier.                                                                ¤}{¤

 ¤}{¤000017: filter ¤}{¤000003: evaluates the source argument and coalesces it to a vector or object, with vectors being ¤}{¤
 ¤}{¤000003:preferred. If either of these operations fail, an error is returned. Afterwards ¤}{¤000017: filter ¤}{¤000003: will     ¤}{¤
 ¤}{¤000003:apply the given ¤}{¤000017: func ¤}{¤000003: to each element (for objects the function is applied to the values) and    ¤}{¤
 ¤}{¤000003:coalesces the result to a boolean. If this yields ¤}{¤000017: true ¤}{¤000003:, the element is kept in the result,      ¤}{¤
 ¤}{¤000003:otherwise it's discarded.                                                                         ¤}{¤

 ¤}{¤000017: func ¤}{¤000003: must be a function that allows being called with exactly 1 argument. If more arguments are ¤}{¤
 ¤}{¤000003:needed, use the other form of ¤}{¤000017: filter ¤}{¤000003:.                                                           ¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (filter source:expression params:vector expr:expression) ¤}{¤000008: ➜ ¤}{¤000017: any ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: source ¤}{¤000004: is an arbitrary expression.                                                            ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: params ¤}{¤000004: is a vector describing the desired loop variable name(s).                              ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: expr ¤}{¤000004: is an arbitrary expression.                                                              ¤}{¤

 ¤}{¤000003:When evaluating more complex conditions, this form can be used. Instead of anonymously applying a ¤}{¤
 ¤}{¤000003:function to each argument, this form allows to set the index/value (for vectors) or key/value (for¤}{¤
 ¤}{¤000003:objects) as variables, which can then be used in arbitrary expressions, for example:              ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (filter .data [value] (not (empty? $value))) ¤}{¤000004:                                                  ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (filter .data [idx value] (gt? $idx 1)) ¤}{¤000004:                                                       ¤}{¤

 ¤}{¤000017: params ¤}{¤000003: must be a vector containing one or two identifiers. If a single identifier is given, it's¤}{¤
 ¤}{¤000003:the variable name for the value. If two identifiers are given, the first is used for the          ¤}{¤
 ¤}{¤000003:index/key, the second is used for the value.                                                      ¤}{¤

 ¤}{¤000017: expr ¤}{¤000003: can then be any expression. Just like the other form, ¤}{¤000017: source ¤}{¤000003: is evaluated and coalesced  ¤}{¤
 ¤}{¤000003:to vector/object and the expression is then applied to each element, keeping only those for which ¤}{¤
 ¤}{¤000003:the expression yields a boolish value.                                                            ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: filter ¤}{¤000003: evaluates all expressions using a shared context, so it's possible for the filter        ¤}{¤
 ¤}{¤000003:functions to share variables.                                                                     ¤}{¤

¤}