{¤
 ¤}{¤000006: delete ¤}{¤

 ¤}{¤000017: delete ¤}{¤000003: removes a key from an object or an item from a vector (shrinking that vector by 1        ¤}{¤
 ¤}{¤000003:element). It must be used on any expression that has a path expression attached (e.g. ¤}{¤000017: (delete (do-¤}{¤
 ¤}{¤000017:something).gone) ¤}{¤000003:).                                                                               ¤}{¤

 ¤}{¤000003:Note that ¤}{¤000017: delete ¤}{¤000003: is, like all functions in Rudi, stateless and so does not modify the given     ¤}{¤
 ¤}{¤000003:argument directly. That is why ¤}{¤000017: delete ¤}{¤000003: can be used on non-variables/documents, like in ¤}{¤000017: (delete¤}{¤000003:  ¤}{¤
 ¤}{¤000017:(read-config).password) ¤}{¤000003: to get rid of individual keys from a larger data structure. To enable    ¤}{¤
 ¤}{¤000003:this, ¤}{¤000017: delete ¤}{¤000003: always returns the ¤}{¤00000d:remaining¤}{¤000003: datastructure, not the value that was removed.        ¤}{¤

 ¤}{¤000003:To make your changes "stick", use the bang modifier: ¤}{¤000017: (delete! $var.foo) ¤}{¤000003: – this only makes sense ¤}{¤
 ¤}{¤000003:for symbols (i.e. variables and the global document), since there is no "source" to be updated for¤}{¤
 ¤}{¤000003:e.g. literals (hence ¤}{¤000017: (delete! [1 2 3][1]) ¤}{¤000003: is invalid).                                          ¤}{¤

 ¤}{¤000017: set ¤}{¤000003: is another function that is most often used with the bang modifier and also returns the     ¤}{¤
 ¤}{¤000003:entire datastructure, not just the newly inserted value.                                          ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (delete! $var.key) ¤}{¤000004:                                                                            ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (delete! .[1]) ¤}{¤000004:                                                                                ¤}{¤

 ¤}{¤000003:This function is mostly used with the bang modifier, but can sometimes also be useful without if  ¤}{¤
 ¤}{¤000003:you only want to modify an object/vector "in transit":                                            ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (connect (delete (read-config).isAdmin)) ¤}{¤000004: to give ¤}{¤000017: connect ¤}{¤000004: a config object                    ¤}{¤
 ¤}{¤000004:object without the ¤}{¤000017: isAdmin ¤}{¤000004: flag.                                                                ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (delete target:pathed) ¤}{¤000008: ➜ ¤}{¤000017: any ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: target ¤}{¤000004: is a any expression with a path expression.                                            ¤}{¤

 ¤}{¤000017: delete ¤}{¤000003: evaluates the target expression and then removes whatever the path expression is pointing¤}{¤
 ¤}{¤000003:to. The return value is the remaining data (i.e. not the removed value).                          ¤}{¤

 ¤}{¤000003:When used with the bang modifier, ¤}{¤000017: target ¤}{¤000003: must be a symbol with a path expression.               ¤}{¤

¤}