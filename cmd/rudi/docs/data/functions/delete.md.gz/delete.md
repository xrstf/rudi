{¤
 ¤}{¤000006: delete ¤}{¤

 ¤}{¤000017: delete ¤}{¤000003: removes a key from an object or an item from a vector (shrinking that vector by 1        ¤}{¤
 ¤}{¤000003:element). It must be used with a path expression and can be used on expressions that support path ¤}{¤
 ¤}{¤000003:expressions (e.g. ¤}{¤000017: (delete (do-something).gone) ¤}{¤000003:).                                                ¤}{¤

 ¤}{¤000003:Note that ¤}{¤000017: delete ¤}{¤000003: is, like all functions in Rudi, stateless and so does not modify the given     ¤}{¤
 ¤}{¤000003:argument directly. To make your changes "stick", use the bang modifier: ¤}{¤000017: (delete! $var.foo) ¤}{¤000003: –    ¤}{¤
 ¤}{¤000003:this only makes sense for symbols (i.e. variables and the global document), which is incidentally ¤}{¤
 ¤}{¤000003:also what the bang modifier itself already enforces. So an expression like ¤}{¤000017: (delete! [1 2][1]) ¤}{¤000003: is¤}{¤
 ¤}{¤000003:invalid.                                                                                          ¤}{¤

 ¤}{¤000017: set ¤}{¤000003: is another function that is most often used with the bang modifier.                         ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (delete! $var.key) ¤}{¤000004:                                                                            ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (delete! .[1]) ¤}{¤000004:                                                                                ¤}{¤

 ¤}{¤000003:This function is mostly used with the bang modifier, but can sometimes also be useful without if  ¤}{¤
 ¤}{¤000003:you only want to modify an object/vector "in transit":                                            ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (handle (delete (read-config).isAdmin)) ¤}{¤000004: to give ¤}{¤000017: handle ¤}{¤000004: a config object                      ¤}{¤
 ¤}{¤000004:object without the ¤}{¤000017: isAdmin ¤}{¤000004: flag.                                                                ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (delete target) ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: target ¤}{¤000004: is any expression that supports path expressions (symbols, tuples,                     ¤}{¤
 ¤}{¤000004:vector nodes and object nodes)                                                                    ¤}{¤

 ¤}{¤000017: delete ¤}{¤000003: evaluates the target expression and then removes whatever the path expression is pointing¤}{¤
 ¤}{¤000003:to. The return value is the remaining data (i.e. not the removed value).                          ¤}{¤

 ¤}{¤000003:When used with the bang modifier, ¤}{¤000017: target ¤}{¤000003: must be a symbol with a path expression.               ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: delete ¤}{¤000003: evaluates the expression in its own scope, so variables defined in it do not leak.       ¤}{¤

¤}