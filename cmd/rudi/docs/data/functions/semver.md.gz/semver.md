{¤
 ¤}{¤000006: semver ¤}{¤

 ¤}{¤000003:This function will parse a string as a semantic version. The parsing is "relaxed", allowing for a ¤}{¤
 ¤}{¤000003:leading ¤}{¤000017: "v" ¤}{¤000003: and the least significant parts can be left out when they are zero (e.g. ¤}{¤000017: "v1.0.0" ¤}{¤000003: ¤}{¤
 ¤}{¤000003:is just as valid as ¤}{¤000017: "1" ¤}{¤000003:).                                                                       ¤}{¤

 ¤}{¤000003:Parsed semvers are a custom type (not a string, not a vector). They can be directly compared to   ¤}{¤
 ¤}{¤000003:each other and to strings (i.e. they can be coalesced to a string, depending on the coalescer).   ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (semver "v1.2") ¤}{¤000004: ➜ semver object                                                               ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (semver "foo") ¤}{¤000004: ➜ error                                                                        ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (eq? (to-string (semver "v1.0")) "1.0.0") ¤}{¤000004: ➜ ¤}{¤000017: true ¤}{¤000004:                                            ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (eq? (semver "v1.0") "1.0.0") ¤}{¤000004: ➜ ¤}{¤000017: true ¤}{¤000004: (with human coalescing)                                ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (gt? (semver "v1.0") (semver "v1.0.1")) ¤}{¤000004: ➜ ¤}{¤000017: false ¤}{¤000004:                                             ¤}{¤

¤}