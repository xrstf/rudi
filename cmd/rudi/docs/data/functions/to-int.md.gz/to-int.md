{¤
 ¤}{¤000006: to-int ¤}{¤

 ¤}{¤000017: to-int ¤}{¤000003: converts the given value to an integer number. The function always uses humane coalescing.¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (to-int "0") ¤}{¤000004: ➜ ¤}{¤000017: 0 ¤}{¤000004:                                                                            ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (to-int 1.0) ¤}{¤000004: ➜ ¤}{¤000017: 1 ¤}{¤000004:                                                                            ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (to-int 1.2) ¤}{¤000004: ➜ error, no lossless conversion possible                                         ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (to-int []) ¤}{¤000004: ➜ error                                                                           ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (to-int value:any) ¤}{¤000008: ➜ ¤}{¤000017: int ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: value ¤}{¤000004: is an arbitrary expression.                                                             ¤}{¤

 ¤}{¤000017: to-int ¤}{¤000003: evaluates the given expression and then coalesces the result into an integer value. See  ¤}{¤
 ¤}{¤000003:the documentation for the humane coalescer for the exact conversion rules.                        ¤}{¤

¤}