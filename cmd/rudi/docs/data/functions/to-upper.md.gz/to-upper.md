{¤
 ¤}{¤000006: to-upper ¤}{¤

 ¤}{¤000017: to-upper ¤}{¤000003: removes a copy of a string with all lowercase characters replaced with their uppercase ¤}{¤
 ¤}{¤000003:equivalent. This function uses Go's regular strings package and so this function should not be    ¤}{¤
 ¤}{¤000003:used where Unicode characters are involved, unexpected results might happen.                      ¤}{¤

 ¤}{¤000003:See also ¤}{¤000017: to-lower ¤}{¤000003:.                                                                              ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (to-upper "foo") ¤}{¤000004: ➜ ¤}{¤000017: "FOO" ¤}{¤000004:                                                                    ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (to-upper value:string) ¤}{¤000008: ➜ ¤}{¤000017: string ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: value ¤}{¤000004: is an arbitrary expression.                                                             ¤}{¤

 ¤}{¤000003:Returns a copy of the value with all bytes being turned to their uppercase equivalent.            ¤}{¤

¤}