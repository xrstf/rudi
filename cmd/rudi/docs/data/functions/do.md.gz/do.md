{¤
 ¤}{¤000006: do ¤}{¤

 ¤}{¤000017: do ¤}{¤000003: evaluates all expressions in sequence, sharing a context between them. This effectively forms¤}{¤
 ¤}{¤000003:a sub program and is useful for combining with other functions that require exactly 1 expression, ¤}{¤
 ¤}{¤000003:like an ¤}{¤000017: if ¤}{¤000003:: ¤}{¤000017: (if .condition (do (step-1) (step-2))) ¤}{¤000003:                                            ¤}{¤

 ¤}{¤000017: do ¤}{¤000003: purposefully makes its child expressions have side effects, so that setting variables has an ¤}{¤
 ¤}{¤000003:effect on subsequent expressions.                                                                 ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (do true 42) ¤}{¤000004: ➜ ¤}{¤000017: 42 ¤}{¤000004:                                                                           ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (do (set! $foo 1) (+ $foo 2)) ¤}{¤000004: ➜ ¤}{¤000017: 3 ¤}{¤000004:                                                           ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (do expr:expression…) ¤}{¤000008: ➜ ¤}{¤000017: any ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: expr ¤}{¤000004: is 1 or more expressions                                                                 ¤}{¤

 ¤}{¤000017: do ¤}{¤000003: evaluates sets up a new context and then evaluates all expressions in sequence, sharing the  ¤}{¤
 ¤}{¤000003:context between them, forming a sub program. The return value of ¤}{¤000017: do ¤}{¤000003: is the return value of the  ¤}{¤
 ¤}{¤000003:last expression in it.                                                                            ¤}{¤

 ¤}{¤000003:When any expression encounters an error, ¤}{¤000017: do ¤}{¤000003: stops evaluation and returns the error.             ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: do ¤}{¤000003: shares a context between all child expressions.                                              ¤}{¤

¤}