{¤
 ¤}{¤000006: func! ¤}{¤

 ¤}{¤000003:This function can be used to define new functions at runtime.                                     ¤}{¤

 ¤}{¤000007:## Unsafe Note¤}{¤

 ¤}{¤000003:This function is considered unsafe because it allows the creation of programs like:               ¤}{¤

   ¤}{¤d70000:(func! foo [] (bar))                                                                            ¤}{¤
   ¤}{¤d70000:(func! bar [] (foo))                                                                            ¤}{¤
   ¤}{¤d70000:(foo)                                                                                           ¤}{¤

 ¤}{¤000003:which will never terminate, breaking one of Rudi's promises. Because of this, ¤}{¤000017: func! ¤}{¤000003: is not      ¤}{¤
 ¤}{¤000003:enabled by default and needs to be enabled using ¤}{¤000017: --enable-funcs ¤}{¤000003: when using the Rudi interpreter or¤}{¤
 ¤}{¤000003:by including the ¤}{¤000017: rudifunc ¤}{¤000003: module when embedding Rudi into other Go applications.                ¤}{¤

 ¤}{¤000007:## Usage¤}{¤

 ¤}{¤000017: func! ¤}{¤000003: creates a new function, which can be used in all subseqeuent statements in the same Rudi  ¤}{¤
 ¤}{¤000003:program. Function creation is bound to its parent scope, so defining a function within an ¤}{¤000017: if ¤}{¤000003:    ¤}{¤
 ¤}{¤000003:statement for example will make the function available onside inside that statement, not globally.¤}{¤

 ¤}{¤000003:Dynamically defined functions cannot overwrite statically defined functions, i.e. you cannot      ¤}{¤
 ¤}{¤000003:define a custom ¤}{¤000017: concat ¤}{¤000003: function using ¤}{¤000017: func! ¤}{¤000003: if ¤}{¤000017: concat ¤}{¤000003: already exists (which is highly       ¤}{¤
 ¤}{¤000003:likely, given that it's a safe built-in function). Dynamically defined functions can be overwritten¤}{¤
 ¤}{¤000003:(redefined) though.                                                                               ¤}{¤

 ¤}{¤000003:Since defining a new function is a side effect, ¤}{¤000017: func ¤}{¤000003: must always be used with the bang modifier ¤}{¤
 ¤}{¤000003:(¤}{¤000017: func! ¤}{¤000003:). The behaviour of Rudi programs that use ¤}{¤000017: func ¤}{¤000003: without the bang modifier is undefined. ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

   ¤}{¤d70000:(func! myconcat [list] (concat "-" $list))                                                      ¤}{¤
   ¤}{¤d70000:(myconcat ["1" "2" "3"]) # yields "1-2-3"                                                       ¤}{¤

   ¤}{¤d70000:(func! fib [n]                                                                                  ¤}{¤
   ¤}{¤d70000:  (if (lte? $n 1)                                                                               ¤}{¤
   ¤}{¤d70000:    0                                                                                           ¤}{¤
   ¤}{¤d70000:    (if (eq? $n 2)                                                                              ¤}{¤
   ¤}{¤d70000:      1                                                                                         ¤}{¤
   ¤}{¤d70000:      (+ (fib (- $n 1)) (fib (- $n 2))))))                                                      ¤}{¤

 ¤}{¤000003:Note that Rudi is not optimized for performance and so the function above is very slow and will   ¤}{¤
 ¤}{¤000003:quickly exhaust space and time. If you need performance, inject a Go function statically into Rudi¤}{¤
 ¤}{¤000003:instead of defining it at runtime.                                                                ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (func! name:identifier params:vector body:expression) ¤}{¤000008: ➜ ¤}{¤000017: null ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: name ¤}{¤000004: is an identifier giving the function its name.                                           ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: params ¤}{¤000004: is a vector containing identifiers that hold the parameter names.                      ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: body ¤}{¤000004: is a single expression (use ¤}{¤000017: do ¤}{¤000004: for multiple statements) that forms                     ¤}{¤
 ¤}{¤000004:the function body.                                                                                ¤}{¤

 ¤}{¤000003:This form will create a new function called ¤}{¤000017: name ¤}{¤000003: with as many parameters as ¤}{¤000017: params ¤}{¤000003: has        ¤}{¤
 ¤}{¤000003:identifiers. ¤}{¤000017: params ¤}{¤000003: can be empty, but must otherwise contain only unique identifiers.           ¤}{¤

 ¤}{¤000017: name ¤}{¤000003: must be a bare identifier without the bang modifier (¤}{¤000017: ! ¤}{¤000003:). The bang modifier is a Rudi     ¤}{¤
 ¤}{¤000003:runtime functionality that functions get by default, so defining a function ¤}{¤000017: foo ¤}{¤000003: will            ¤}{¤
 ¤}{¤000003:automatically make ¤}{¤000017: foo! ¤}{¤000003: available as well, with the same behaviour as built-in functions, for   ¤}{¤
 ¤}{¤000003:example:                                                                                          ¤}{¤

   ¤}{¤d70000:(func! inc [n] (+ $n 1))                                                                        ¤}{¤
   ¤}{¤d70000:(set! $a 1)                                                                                     ¤}{¤
   ¤}{¤d70000:                                                                                                ¤}{¤
   ¤}{¤d70000:(inc $a) # yields 2                                                                             ¤}{¤
   ¤}{¤d70000:$a       # yields 1                                                                             ¤}{¤
   ¤}{¤d70000:                                                                                                ¤}{¤
   ¤}{¤d70000:(inc! $a) # yields 2                                                                            ¤}{¤
   ¤}{¤d70000:$a        # yields 2                                                                            ¤}{¤

 ¤}{¤000003:The newly defined function can then be called like any other built-in function in Rudi, for example¤}{¤
 ¤}{¤000003:the above function ¤}{¤000017: inc ¤}{¤000003: can be used with ¤}{¤000017: map ¤}{¤000003::                                                  ¤}{¤

   ¤}{¤d70000:(func! inc [n] (+ $n 1))                                                                        ¤}{¤
   ¤}{¤d70000:(map [1 2 3] inc) # yields [2 3 4]                                                              ¤}{¤

 ¤}{¤000017: func ¤}{¤000003: should never be called without the bang modifier, as its behaviour is undefined in thatcase¤}{¤
 ¤}{¤000003:and the return value is unusable.                                                                 ¤}{¤

 ¤}{¤000017: func! ¤}{¤000003: always returns ¤}{¤000017: null ¤}{¤000003:.                                                                    ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000003:Since defining a function is literally a side effect, ¤}{¤000017: func! ¤}{¤000003: must always be called with the bang ¤}{¤
 ¤}{¤000003:modifier.                                                                                         ¤}{¤

¤}