{¤
 ¤}{¤000006: default ¤}{¤

 ¤}{¤000017: default ¤}{¤000003: is used to apply default values, especially when reading data from user-defined inputs. ¤}{¤
 ¤}{¤000003:Because of this, ¤}{¤000017: default ¤}{¤000003: uses a loose definition when determining emptyness by using the ¤}{¤000017: empty? ¤}{¤
 ¤}{¤000003:function internally. This means values like ¤}{¤000017: 0 ¤}{¤000003: or ¤}{¤000017: "" ¤}{¤000003: are considered empty.                     ¤}{¤

 ¤}{¤000017: default ¤}{¤000003: is similar to ¤}{¤000017: try ¤}{¤000003:, but only returns the fallback value if the value is empty-ish. If an¤}{¤
 ¤}{¤000003:error occurs, ¤}{¤000017: default ¤}{¤000003: does not fall back to the fallback value, but returns the error instead.  ¤}{¤

 ¤}{¤000017: default ¤}{¤000003: is a shortcut to writing ¤}{¤000017: (if (empty? expr-a) expr-b expr-a) ¤}{¤000003:                           ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (default "" "fallback") ¤}{¤000004: -> ¤}{¤000017: "fallback" ¤}{¤000004:                                                       ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (default "set" "fallback") ¤}{¤000004: -> ¤}{¤000017: "set" ¤}{¤000004:                                                         ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (default (+ "invalid") "fallback") ¤}{¤000004: -> error                                                   ¤}{¤

 ¤}{¤000003:The function is also nice when combined with the bang modifier to apply default values to a       ¤}{¤
 ¤}{¤000003:variable:                                                                                         ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (default! $var.foo "default-value") ¤}{¤000004:                                                           ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (default candidate fallback) ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: candidate ¤}{¤000004: is an arbitrary expression.                                                         ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: fallback ¤}{¤000004: is an arbitrary expression.                                                          ¤}{¤

 ¤}{¤000017: default ¤}{¤000003: evaluates the candidate expression and returns the evaluated fallback value if the      ¤}{¤
 ¤}{¤000003:returned candidate value is empty-ish. If the candidate expression returns an error, the error is ¤}{¤
 ¤}{¤000003:returned and the fallback expressions is not evaluated.                                           ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: default ¤}{¤000003: executes candidate and fallback in their own scopes, so variables from either expression¤}{¤
 ¤}{¤000003:are not visible in the other and neither leak outside of ¤}{¤000017: default ¤}{¤000003:.                               ¤}{¤

¤}