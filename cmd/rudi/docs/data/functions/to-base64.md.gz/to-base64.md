{¤
 ¤}{¤000006: to-base64 ¤}{¤

 ¤}{¤000017: to-base64 ¤}{¤000003: encodes string with base64. See also the inverse function ¤}{¤000017: from-base64 ¤}{¤000003:.              ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (to-base64 "") ¤}{¤000004: ➜ ¤}{¤000017: "" ¤}{¤000004:                                                                         ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (to-base64 "hello") ¤}{¤000004: ➜ ¤}{¤000017: "aGVsbG8=" ¤}{¤000004:                                                            ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (to-base64 data:string) ¤}{¤000008: ➜ ¤}{¤000017: string ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: data ¤}{¤000004: is an arbitrary expression.                                                              ¤}{¤

 ¤}{¤000017: to-base64 ¤}{¤000003: evaluates the given expression and coalesces the result to a string. If either of those¤}{¤
 ¤}{¤000003:steps fail, an error is returned. Otherwise the function will encode the string with base64 and   ¤}{¤
 ¤}{¤000003:return the result.                                                                                ¤}{¤

¤}