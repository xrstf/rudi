{¤
 ¤}{¤000006: to-string ¤}{¤

 ¤}{¤000017: to-string ¤}{¤000003: converts the given value to a string. The function always uses humane coalescing.     ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (to-string null) ¤}{¤000004: ➜ ¤}{¤000017: "" ¤}{¤000004:                                                                       ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (to-string true) ¤}{¤000004: ➜ ¤}{¤000017: "true" ¤}{¤000004:                                                                   ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (to-string false) ¤}{¤000004: ➜ ¤}{¤000017: "false" ¤}{¤000004:                                                                 ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (to-string 0) ¤}{¤000004: ➜ ¤}{¤000017: "0" ¤}{¤000004:                                                                         ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (to-string 1.1) ¤}{¤000004: ➜ ¤}{¤000017: "1.1" ¤}{¤000004:                                                                     ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (to-string []) ¤}{¤000004: ➜ error                                                                        ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (to-string value:any) ¤}{¤000008: ➜ ¤}{¤000017: string ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: value ¤}{¤000004: is an arbitrary expression.                                                             ¤}{¤

 ¤}{¤000017: to-string ¤}{¤000003: evaluates the given expression and then coalesces the result into a string value. See ¤}{¤
 ¤}{¤000003:the documentation for the humane coalescer for the exact conversion rules.                        ¤}{¤

¤}