{¤
 ¤}{¤000006: from-yaml ¤}{¤

 ¤}{¤000003:This function does things.                                                                        ¤}{¤

¤}