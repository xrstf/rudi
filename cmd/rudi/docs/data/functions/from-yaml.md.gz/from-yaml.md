{¤
 ¤}{¤000006: from-yaml ¤}{¤

 ¤}{¤000003:This function decodes a YAML string into a Go datastructure.                                      ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (from-yaml "foo: 23") ¤}{¤000004: ➜ ¤}{¤000017: {"foo" 23} ¤}{¤000004:                                                          ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (from-yaml "~") ¤}{¤000004: ➜ ¤}{¤000017: null ¤}{¤000004:                                                                      ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (from-yaml markup:string) ¤}{¤000008: ➜ ¤}{¤000017: any ¤}{¤

 ¤}{¤000003:This is the only form of this function. It decodes a YAML string and returns the result. If       ¤}{¤
 ¤}{¤000003:invalid YAML is provided, an error is thrown.                                                     ¤}{¤

¤}