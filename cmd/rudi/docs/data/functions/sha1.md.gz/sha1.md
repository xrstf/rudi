{¤
 ¤}{¤000006: sha1 ¤}{¤

 ¤}{¤000017: sha1 ¤}{¤000003: returns the lowercase hex string presenration of the SHA-1 hash of the given input value.  ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (sha1 "") ¤}{¤000004: -> ¤}{¤000017: "da39a3ee5e6b4b0d3255bfef95601890afd80709" ¤}{¤000004:                                     ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (sha1 "hello") ¤}{¤000004: -> ¤}{¤000017: "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d" ¤}{¤000004:                                ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (sha1 data) ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: data ¤}{¤000004: is an arbitrary expression.                                                              ¤}{¤

 ¤}{¤000017: sha1 ¤}{¤000003: evaluates the given expression and coalesces the result to a string. If either of those    ¤}{¤
 ¤}{¤000003:steps fail, an error is returned. Otherwise the function will calculate the SHA-1 hash and return ¤}{¤
 ¤}{¤000003:the hex presentation (a string of 40 characters).                                                 ¤}{¤

¤}