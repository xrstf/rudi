{¤
 ¤}{¤000006: has-prefix? ¤}{¤

 ¤}{¤000017: has-prefix? ¤}{¤000003: checks whether a given string begins with another string.                           ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (has-prefix? "hello" "hell") ¤}{¤000004: -> ¤}{¤000017: true ¤}{¤000004:                                                        ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (has-prefix? "hallo" "halloween") ¤}{¤000004: -> ¤}{¤000017: false ¤}{¤000004:                                                  ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (has-prefix? "foo" "bar") ¤}{¤000004: -> ¤}{¤000017: false ¤}{¤000004:                                                          ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (has-prefix? base prefix) ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: base ¤}{¤000004: is an arbitrary expression.                                                              ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: prefix ¤}{¤000004: is an arbitrary expression.                                                            ¤}{¤

 ¤}{¤000017: has-prefix? ¤}{¤000003: evaluates the first argument and coalesces it into a string. If successful, it      ¤}{¤
 ¤}{¤000003:evalates the prefix the same way. If both values are strings, the function returns true if ¤}{¤000017: base ¤}{¤000003: ¤}{¤
 ¤}{¤000003:begins with ¤}{¤000017: prefix ¤}{¤000003:.                                                                             ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: has-prefix? ¤}{¤000003: executes all expressions in their own contexts, so nothing is shared.               ¤}{¤

¤}