{¤
 ¤}{¤000006: like? ¤}{¤

 ¤}{¤000017: like? ¤}{¤000003: compares two arguments for equalities. Equality is defined using the humane coalescer, so ¤}{¤
 ¤}{¤000017:(like? 1 "1") ¤}{¤000003: yields no type error, but true.                                                    ¤}{¤

 ¤}{¤000003:See also ¤}{¤000017: eq? ¤}{¤000003:, which uses the currently selected coalescer, and ¤}{¤000017: identical? ¤}{¤000003:, which always uses  ¤}{¤
 ¤}{¤000003:strict coalescing.                                                                                ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (like? 1 "1") ¤}{¤000004: ➜ ¤}{¤000017: true ¤}{¤000004:                                                                        ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (like? 1 "2") ¤}{¤000004: ➜ ¤}{¤000017: false ¤}{¤000004:                                                                       ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (like? left:any right:any) ¤}{¤000008: ➜ ¤}{¤000017: bool ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: left ¤}{¤000004: is an arbitrary expression, except for identifiers.                                      ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: right ¤}{¤000004: is likewise an arbitrary expression, except for identifiers.                            ¤}{¤

 ¤}{¤000003:Both expressions are evaluated and then compared using the current coalescer. If evaluation of    ¤}{¤
 ¤}{¤000003:either of the expressions yields and error, that error is returned.                               ¤}{¤

 ¤}{¤000003:Equality is not defined for all type combinations, even with the humane coalescer, and so ¤}{¤000017: like? ¤}{¤000003: ¤}{¤
 ¤}{¤000003:can return errors for invalid comparisons. See the coalescing documentation for conversion rules. ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: like? ¤}{¤000003: executes both expressions in their own contexts, so nothing is shared.                    ¤}{¤

¤}