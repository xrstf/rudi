{¤
 ¤}{¤000006: empty? ¤}{¤

 ¤}{¤000017: empty? ¤}{¤000003: returns ¤}{¤000017: true ¤}{¤000003: if the given value is "empty-ish". The following values are considered    ¤}{¤
 ¤}{¤000003:"empty-ish":                                                                                      ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: null ¤}{¤000004:                                                                                          ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: bool ¤}{¤000004:: ¤}{¤000017: false ¤}{¤000004:                                                                                 ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: number ¤}{¤000004:: ¤}{¤000017: 0 ¤}{¤000004: (integer) and ¤}{¤000017: 0.0 ¤}{¤000004: (float)                                                       ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: string ¤}{¤000004:: ¤}{¤000017: "" ¤}{¤000004: (string of zero length)                                                          ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: vector ¤}{¤000004:: ¤}{¤000017: [] ¤}{¤000004: (vector with 0 elements)                                                         ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: object ¤}{¤000004:: ¤}{¤000017: {} ¤}{¤000004: (object with 0 elements)                                                         ¤}{¤

 ¤}{¤000017: empty? ¤}{¤000003: is primarily intended to deal with malformed/maltyped JSON data.                         ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (empty? "") ¤}{¤000004: ➜ ¤}{¤000017: true ¤}{¤000004:                                                                          ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (empty? 42) ¤}{¤000004: ➜ ¤}{¤000017: false ¤}{¤000004:                                                                         ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (empty? value:any) ¤}{¤000008: ➜ ¤}{¤000017: bool ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: value ¤}{¤000004: is exactly 1 expression.                                                                ¤}{¤

 ¤}{¤000003:The expression is evaluated and if it's empty-ish according to the list above, ¤}{¤000017: true ¤}{¤000003: is returned,¤}{¤
 ¤}{¤000003:else ¤}{¤000017: false ¤}{¤000003:. The expression must be evaluatable, so identifiers cannot be used (¤}{¤000017: (empty? to-upper) ¤}{¤
 ¤}{¤000003:is invalid).                                                                                      ¤}{¤

 ¤}{¤000003:If the expression errors out, ¤}{¤000017: empty? ¤}{¤000003: also returns an error.                                     ¤}{¤

 ¤}{¤000007:## Context¤}{¤

 ¤}{¤000017: empty? ¤}{¤000003: evaluates the expression in its own scope, so variables defined in it do not leak.       ¤}{¤

¤}