{¤
 ¤}{¤000006: from-base64 ¤}{¤

 ¤}{¤000017: from-base64 ¤}{¤000003: decodes a base64-encoded string. See also the inverse function ¤}{¤000017: to-base64 ¤}{¤000003:.         ¤}{¤

 ¤}{¤000007:## Examples¤}{¤

 ¤}{¤000004:• ¤}{¤000017: (from-base64 "") ¤}{¤000004: ➜ ¤}{¤000017: "" ¤}{¤000004:                                                                       ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (from-base64 "invalid") ¤}{¤000004: ➜ error                                                               ¤}{¤
 ¤}{¤000004:• ¤}{¤000017: (from-base64 "aGVsbG8=") ¤}{¤000004: ➜ ¤}{¤000017: "hello" ¤}{¤000004:                                                          ¤}{¤

 ¤}{¤000007:## Forms¤}{¤

 ¤}{¤000008:### ¤}{¤000017: (from-base64 encoded:string) ¤}{¤000008: ➜ ¤}{¤000017: string ¤}{¤

 ¤}{¤000004:• ¤}{¤000017: encoded ¤}{¤000004: is an arbitrary expression.                                                           ¤}{¤

 ¤}{¤000017: from-base64 ¤}{¤000003: evaluates the given expression and coalesces the result to a string. If either of   ¤}{¤
 ¤}{¤000003:those steps fail, an error is returned. Otherwise the function will attempt to decode the value,  ¤}{¤
 ¤}{¤000003:returning the decoded data on success and an error otherwise.                                     ¤}{¤

¤}