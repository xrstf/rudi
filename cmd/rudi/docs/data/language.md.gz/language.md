{¤
 ¤}{¤000006: The Rudi Language ¤}{¤

 ¤}{¤000003:Rudi is a Lisp dialect. Each Rudi program consists of a series of statement, which are tuples (¤}{¤000017: (¤}{¤000003: ¤}{¤
 ¤}{¤000017:... ) ¤}{¤000003:), path expressions (¤}{¤000017: .foo.bar[0] ¤}{¤000003:) or literal values (¤}{¤000017: {foo "bar"} ¤}{¤000003:). Statements are       ¤}{¤
 ¤}{¤000003:separated by whitespace. Each of these statements is evaluated in sequence, with the result of the¤}{¤
 ¤}{¤000003:last statement being the result of the entire program.                                            ¤}{¤

   ¤}{¤d75faf:(¤}{¤d75fd7:set!¤}{¤d70000: ¤}{¤d75f87:.¤}{¤d75fd7:foo¤}{¤d70000: ¤}{¤d787ff:42¤}{¤d75faf:)¤}{¤d70000:                                                                                  ¤}{¤
   ¤}{¤d75faf:(¤}{¤d75fd7:set!¤}{¤d70000: ¤}{¤d75fd7:$var¤}{¤d70000: ¤}{¤d75faf:(¤}{¤d787d7:+¤}{¤d70000: ¤}{¤d75f87:.¤}{¤d75fd7:bar¤}{¤d70000: ¤}{¤d75faf:(¤}{¤d75fd7:len¤}{¤d70000: ¤}{¤d75f87:.¤}{¤d75fd7:users¤}{¤d75faf:)))¤}{¤d70000:                                                               ¤}{¤
   ¤}{¤d75faf:(¤}{¤d787d7:map¤}{¤d70000: ¤}{¤d75fd7:[1¤}{¤d70000: ¤}{¤d787ff:2¤}{¤d70000: ¤}{¤d75fd7:3]¤}{¤d70000: ¤}{¤d75fd7:[x]¤}{¤d70000: ¤}{¤d75faf:(¤}{¤d787d7:+¤}{¤d70000: ¤}{¤d75fd7:$x¤}{¤d70000: ¤}{¤d75fd7:$var¤}{¤d75faf:))¤}{¤d70000:                                                                   ¤}{¤

 ¤}{¤000003:Using path expressions or literal values as statements is usually only useful if your program ends¤}{¤
 ¤}{¤000003:with a literal (often a constructed object) or if you use a path expression to select a sub-value ¤}{¤
 ¤}{¤000003:out of the global document.                                                                       ¤}{¤

 ¤}{¤000003:Most functions can return errors and if an error happens, program execution stops unless the error¤}{¤
 ¤}{¤000003:is caught using the ¤}{¤000017: try ¤}{¤000003: function.                                                               ¤}{¤

 ¤}{¤000007:## Data Types¤}{¤

 ¤}{¤000003:Rudi knows the following data types, known as "literals":                                         ¤}{¤

 ¤}{¤000004:• Null (¤}{¤000017: null ¤}{¤000004:)                                                                                   ¤}{¤
 ¤}{¤000004:• Bools (¤}{¤000017: true ¤}{¤000004: or ¤}{¤000017: false ¤}{¤000004:)                                                                       ¤}{¤
 ¤}{¤000004:• Numbers (int64 like ¤}{¤000017: 42 ¤}{¤000004: or float64 like ¤}{¤000017: 42.42 ¤}{¤000004:)                                               ¤}{¤
 ¤}{¤000004:• Strings (¤}{¤000017: "i am a string" ¤}{¤000004:)                                                                     ¤}{¤
 ¤}{¤000004:• Vectors (¤}{¤000017: [1 2 3] ¤}{¤000004:, items are whitespace separated, but commas can also be used, like ¤}{¤000017: [1, 2, 3]¤}{¤
 ¤}{¤000004:;                                                                                                 ¤}{¤
 ¤}{¤000004:each element of a vector can be any type of expression, e.g. ¤}{¤000017: [1 (+ 1 2)] ¤}{¤000004: to create ¤}{¤000017: [1 3] ¤}{¤000004:)     ¤}{¤
 ¤}{¤000004:• Objects (¤}{¤000017: {"key" "value" "otherkey" "othervalue"} ¤}{¤000004:; keys and values can be any type of          ¤}{¤
 ¤}{¤000004:expressions,                                                                                      ¤}{¤
 ¤}{¤000004:but the key expression must return a string; keys can also be identifiers, i.e. unquoted, so      ¤}{¤
 ¤}{¤000017: {foo "bar"} ¤}{¤000004: is the same as ¤}{¤000017: {"foo" "bar"} ¤}{¤000004:)                                                     ¤}{¤

 ¤}{¤000003:As you can see, Rudi is basically JSON extended with S-expressions.                               ¤}{¤

 ¤}{¤000003:In addition to these literal data types, Rudi understands a number of expressions:                ¤}{¤

 ¤}{¤000007:## Expressions¤}{¤

 ¤}{¤000008:### Null¤}{¤

 ¤}{¤000003:Nulls are the empty value and are always written as ¤}{¤000017: null ¤}{¤000003:, like in JSON. Nulls equal each other, ¤}{¤
 ¤}{¤000003:so ¤}{¤000017: (eq? null null) ¤}{¤000003: is true.                                                                     ¤}{¤

 ¤}{¤000008:### Bool¤}{¤

 ¤}{¤000003:Booleans are the thruth values of ¤}{¤000017: true ¤}{¤000003: (positive) and ¤}{¤000017: false ¤}{¤000003: (negative).                       ¤}{¤

 ¤}{¤000008:### Number¤}{¤

 ¤}{¤000003:Numbers are either 64-bit integers (int64) or 64-bit floating-points (float64). Whole numbers are ¤}{¤000017: 0 ¤}{¤
 ¤}{¤000003:or ¤}{¤000017: 183732627 ¤}{¤000003: or ¤}{¤000017: -17 ¤}{¤000003:. Floating point numbers are integers followed by a decimal fraction, like ¤}{¤
 ¤}{¤000017:0.4 ¤}{¤000003: or ¤}{¤000017: -42.341 ¤}{¤000003:.                                                                                ¤}{¤

 ¤}{¤000003:Integers and floats are not directly comparable, convert the int to a float to perform            ¤}{¤
 ¤}{¤000003:comparisons. Even ¤}{¤000017: 0 ¤}{¤000003: is not equal to ¤}{¤000017: 0.0 ¤}{¤000003: without conversion.                                   ¤}{¤

 ¤}{¤000008:### String¤}{¤

 ¤}{¤000003:Strings are lists of characters, like ¤}{¤000017: "hello world" ¤}{¤000003:. There is no separate type in Rudi for      ¤}{¤
 ¤}{¤000003:single bytes. Strings can be empty (¤}{¤000017: "" ¤}{¤000003:) and leading/trailing whitespace is kept (¤}{¤000017: "  foo  " ¤}{¤000003:    ¤}{¤
 ¤}{¤000003:will not be trimmed automatically). Use ¤}{¤000017: \" ¤}{¤000003: to write a literal ¤}{¤000017: " ¤}{¤000003: inside a string, use ¤}{¤000017: \\ ¤}{¤000003: to  ¤}{¤
 ¤}{¤000003:write a literal ¤}{¤000017: \ ¤}{¤000003: (e.g. ¤}{¤000017: "C:\\dos\\run" ¤}{¤000003:).                                                      ¤}{¤

 ¤}{¤000008:### Vector¤}{¤

 ¤}{¤000003:Vectors are an ordered list of items. A vector starts with the literal ¤}{¤000017: [ ¤}{¤000003: followed by a          ¤}{¤
 ¤}{¤000003:whitespace separated list of expressions, followed by a literal ¤}{¤000017: ] ¤}{¤000003:. Vectors can be empty (¤}{¤000017: [] ¤}{¤000003:). ¤}{¤
 ¤}{¤000003:Instead of whitespace, commas can also be used, e.g. ¤}{¤000017: [1,2,3] ¤}{¤000003:.                                   ¤}{¤

 ¤}{¤000003:The items in a vector do not need to share the same datatype, so ¤}{¤000017: [1 "foo" true] ¤}{¤000003: (number, string,¤}{¤
 ¤}{¤000003:number) is valid.                                                                                 ¤}{¤

 ¤}{¤000008:### Object¤}{¤

 ¤}{¤000003:Objects are unordered sets of key-value pairs. They always begin with a literal ¤}{¤000017: { ¤}{¤000003:, followed by an¤}{¤
 ¤}{¤000003:arbitrary number of key-value pairs. Key and value are each any possible expressions, with        ¤}{¤
 ¤}{¤000003:limitations listed below. Object declarations end with a literal ¤}{¤000017: } ¤}{¤000003:, for example:                ¤}{¤

   ¤}{¤d75fd7:{¤}{¤d7af00:"foo"¤}{¤d70000: ¤}{¤d7af00:"bar"¤}{¤d70000: ¤}{¤d7af00:"secondkey"¤}{¤d70000: ¤}{¤d7af00:"secondvalue"¤}{¤d75fd7:}¤}{¤d70000:                                                         ¤}{¤

   ¤}{¤d75fd7:{¤}{¤d70000:                                                                                               ¤}{¤
   ¤}{¤d70000:  ¤}{¤d75faf:(¤}{¤d75fd7:to-upper¤}{¤d70000: ¤}{¤d7af00:"foo"¤}{¤d75faf:)¤}{¤d70000: ¤}{¤d75faf:(¤}{¤d787d7:+¤}{¤d70000: ¤}{¤d787ff:1¤}{¤d70000: ¤}{¤d787ff:2¤}{¤d75faf:)¤}{¤d70000:                                                                      ¤}{¤
   ¤}{¤d75fd7:}¤}{¤d70000:                                                                                               ¤}{¤

 ¤}{¤000003:Keys and values are separated by whitespace (not with a ¤}{¤000017: : ¤}{¤000003: like in JSON). Likewise, key-value    ¤}{¤
 ¤}{¤000003:pairs are separated from each other by whitespace. In effect, each object declaration needs to    ¤}{¤
 ¤}{¤000003:have an even number of expression in it.                                                          ¤}{¤

 ¤}{¤000003:As a convenience feature, identifiers are also allowed as object keys and will, in this special   ¤}{¤
 ¤}{¤000003:instance, be converted to strings, so ¤}{¤000017: {foo "bar"} ¤}{¤000003: is equivalent to ¤}{¤000017: {"foo" "bar"} ¤}{¤000003:.             ¤}{¤

 ¤}{¤000003:Empty objects are permitted (¤}{¤000017: {} ¤}{¤000003:).                                                               ¤}{¤

 ¤}{¤000003:Note that objects are internally unordered and functions like map or range will have a random     ¤}{¤
 ¤}{¤000003:iteration order. Due to the fact that Go's JSON encoder sorts keys alphabetically when writing    ¤}{¤
 ¤}{¤000003:JSON, this should rarely be of concern.                                                           ¤}{¤

 ¤}{¤000008:### Statement¤}{¤

 ¤}{¤000003:Statements are the top-level elements of an Rudi program and this distinction is mostly useful    ¤}{¤
 ¤}{¤000003:internally to detect the top-level of a Rudi program. A statement can be a tuple (i.e. a function ¤}{¤
 ¤}{¤000003:call), a symbol (a variable and/or path expression) or a literal value.                           ¤}{¤

   ¤}{¤d75faf:(¤}{¤d75fd7:set!¤}{¤d70000: ¤}{¤d75f87:.¤}{¤d75fd7:foo¤}{¤d70000: ¤}{¤d787ff:42¤}{¤d75faf:)¤}{¤d70000:                                                                                  ¤}{¤
   ¤}{¤d75faf:(¤}{¤d75fd7:set!¤}{¤d70000: ¤}{¤d75fd7:$var¤}{¤d70000: ¤}{¤d75faf:(¤}{¤d787d7:+¤}{¤d70000: ¤}{¤d75f87:.¤}{¤d75fd7:bar¤}{¤d70000: ¤}{¤d75faf:(¤}{¤d75fd7:len¤}{¤d70000: ¤}{¤d75f87:.¤}{¤d75fd7:users¤}{¤d75faf:)))¤}{¤d70000:                                                               ¤}{¤
   ¤}{¤d75faf:(¤}{¤d787d7:map¤}{¤d70000: ¤}{¤d75fd7:[1¤}{¤d70000: ¤}{¤d787ff:2¤}{¤d70000: ¤}{¤d75fd7:3]¤}{¤d70000: ¤}{¤d75fd7:[x]¤}{¤d70000: ¤}{¤d75faf:(¤}{¤d787d7:+¤}{¤d70000: ¤}{¤d75fd7:$x¤}{¤d70000: ¤}{¤d75fd7:$var¤}{¤d75faf:))¤}{¤d70000:                                                                   ¤}{¤

 ¤}{¤000008:### Tuple¤}{¤

 ¤}{¤000003:A tuple always consists of the literal ¤}{¤000017: ( ¤}{¤000003:, followed by one or more expressions, followed by a ¤}{¤000017: )¤}{¤000003: ¤}{¤
 ¤}{¤000003:. Within tuples, any amount of whitespace is allowed. Each of the expressions are separated from  ¤}{¤
 ¤}{¤000003:another by whitespace.                                                                            ¤}{¤

   ¤}{¤d75faf:(¤}{¤d75fff:do¤}{¤d70000: ¤}{¤d75fd7:something¤}{¤d75faf:)¤}{¤d70000:                                                                                  ¤}{¤
   ¤}{¤d75faf:(¤}{¤d75fff:do¤}{¤d70000: ¤}{¤d75fd7:other¤}{¤d70000: ¤}{¤d75fd7:things¤}{¤d75faf:)¤}{¤d70000:                                                                               ¤}{¤
   ¤}{¤d75faf:(¤}{¤d75fd7:add¤}{¤d70000: ¤}{¤d75fd7:this¤}{¤d70000: ¤}{¤d75fd7:to¤}{¤d70000: ¤}{¤d75fd7:that¤}{¤d75faf:)¤}{¤d70000:                                                                              ¤}{¤

 ¤}{¤000003:Tuples represent "function calls". The first element of every tuple must be an ¤}{¤00000e:identifier¤}{¤000003:, which  ¤}{¤
 ¤}{¤000003:is an unquoted string that refers to a built-in function. For example, the ¤}{¤000017: to-upper ¤}{¤000003: function can¤}{¤
 ¤}{¤000003:be called by writing                                                                              ¤}{¤

   ¤}{¤d75faf:(¤}{¤d75fd7:to-upper¤}{¤d70000: ¤}{¤d7af00:"foo"¤}{¤d75faf:)¤}{¤d70000:                                                                                ¤}{¤

 ¤}{¤000003:In general, any kind of expression can follow function names inside tuples. The number of         ¤}{¤
 ¤}{¤000003:expressions depends on the function (¤}{¤000017: to-upper ¤}{¤000003: requires exactly 1 argument, ¤}{¤000017: concat ¤}{¤000003: takes 2 or  ¤}{¤
 ¤}{¤000003:more arguments). However there are special cases where only certain kinds of expressions are      ¤}{¤
 ¤}{¤000003:allowed, like on functions with the bang modifier, which must use a symbol as their first argument¤}{¤
 ¤}{¤000003:(like ¤}{¤000017: (set! $var 42 ¤}{¤000003:).                                                                           ¤}{¤

 ¤}{¤000003:Since tuples are expressions, tuples can be nested:                                               ¤}{¤

   ¤}{¤d75faf:(¤}{¤d75fd7:to-upper¤}{¤d70000: ¤}{¤d75faf:(¤}{¤d75fd7:to-lower¤}{¤d70000: ¤}{¤d7af00:"FOO"¤}{¤d75faf:))¤}{¤d70000:                                                                     ¤}{¤

 ¤}{¤000003:In the example above, the string ¤}{¤000017: "FOO" ¤}{¤000003: would first be lowercased, and the result of the inner   ¤}{¤
 ¤}{¤000003:tuple (¤}{¤000017: "foo" ¤}{¤000003:) would then be uppercased.                                                         ¤}{¤

 ¤}{¤000003:Tuples (i.e. functions) can return any of the known data types (numbers, strings, ...), but not   ¤}{¤
 ¤}{¤000003:other expressions (a tuple cannot return an identifier, for example). This means the function name¤}{¤
 ¤}{¤000003:cannot by dynamic, you cannot do ¤}{¤000017: ((concat "-" "to" "upper") "foo") ¤}{¤000003: to call ¤}{¤000017: (to-upper "foo") ¤}{¤000003:.  ¤}{¤

 ¤}{¤000008:### Bang Modifier¤}{¤

 ¤}{¤000003:Functions in Rudi are stateless, meaning they compute a value and return it, without any side     ¤}{¤
 ¤}{¤000003:effects. However that alone would be boring and not really helpful, so Rudi breaks the pure       ¤}{¤
 ¤}{¤000003:functional approach and allows side effects.                                                      ¤}{¤

 ¤}{¤000003:For example, to set (define or update) a variable, the expression ¤}{¤000017: (set $var 42) ¤}{¤000003: would not do    ¤}{¤
 ¤}{¤000003:what you might think: ¤}{¤00000d:Within¤}{¤000003: the tuple, the ¤}{¤000017: set ¤}{¤000003: will define the variable and the its value to   ¤}{¤
 ¤}{¤000017:42 ¤}{¤000003:, but this will not affect the ¤}{¤00000d:next¤}{¤000003: tuple after it. So for example the program ¤}{¤000017: (set $var 42)¤}{¤000003:  ¤}{¤
 ¤}{¤000017:$var ¤}{¤000003: will error out because ¤}{¤000017: $var ¤}{¤000003: is not defined in the second statement.                       ¤}{¤

 ¤}{¤000003:To "make changes stick", use the bang modifier (¤}{¤000017: ! ¤}{¤000003:): ¤}{¤000017: (set! $var 42) $var ¤}{¤000003: will actually return  ¤}{¤
 ¤}{¤000017:42 ¤}{¤000003:. The bang modifier can be used on any function, as long as the first argument is a symbol     ¤}{¤
 ¤}{¤000003:(i.e. a variable or a bare path expression). If the modifier is used, the result of the function  ¤}{¤
 ¤}{¤000003:expression is updated in the symbol, so ¤}{¤000017: (set! $var 42) ¤}{¤000003: will first calculate the desired value ( ¤}{¤
 ¤}{¤000017:42 ¤}{¤000003:, easy in this case) and then actually set the variable to that value.                         ¤}{¤

 ¤}{¤000003:The difference is more obvious with other functions:                                              ¤}{¤

   ¤}{¤d75faf:(¤}{¤d75fd7:set!¤}{¤d70000: ¤}{¤d75fd7:$var¤}{¤d70000: ¤}{¤d7af00:"foo"¤}{¤d75faf:)¤}{¤d70000:      ¤}{¤d7005f:#¤}{¤d70000: ¤}{¤d75fd7:assign¤}{¤d70000: ¤}{¤d7af00:"foo"¤}{¤d70000: ¤}{¤d75fd7:to¤}{¤d70000: ¤}{¤d75fd7:$var¤}{¤d70000:                                                   ¤}{¤
   ¤}{¤d70000:                                                                                                ¤}{¤
   ¤}{¤d75faf:(¤}{¤d787d7:append¤}{¤d70000: ¤}{¤d75fd7:$var¤}{¤d70000: ¤}{¤d7af00:"bar"¤}{¤d75faf:)¤}{¤d70000:    ¤}{¤d7005f:#¤}{¤d70000: ¤}{¤d75fd7:returns¤}{¤d70000: ¤}{¤d75fd7:a¤}{¤d70000: ¤}{¤d75fd7:new¤}{¤d70000: ¤}{¤d78787:string¤}{¤d70000: ¤}{¤d7af00:"foobar"¤}{¤d70000: ¤}{¤d75fd7:without¤}{¤d70000: ¤}{¤d75fd7:updating¤}{¤d70000: ¤}{¤d75fd7:$var¤}{¤d70000:                    ¤}{¤
   ¤}{¤d75fd7:$var¤}{¤d70000:                   ¤}{¤d7005f:#¤}{¤d70000: ¤}{¤d75fd7:will¤}{¤d70000: ¤}{¤d787d7:print¤}{¤d70000: ¤}{¤d7af00:"foo"¤}{¤d70000:                                                       ¤}{¤
   ¤}{¤d70000:                                                                                                ¤}{¤
   ¤}{¤d75faf:(¤}{¤d75fd7:append!¤}{¤d70000: ¤}{¤d75fd7:$var¤}{¤d70000: ¤}{¤d7af00:"bar"¤}{¤d75faf:)¤}{¤d70000:   ¤}{¤d7005f:#¤}{¤d70000: ¤}{¤d75fd7:returns¤}{¤d70000: ¤}{¤d75fd7:a¤}{¤d70000: ¤}{¤d75fd7:new¤}{¤d70000: ¤}{¤d78787:string¤}{¤d70000: ¤}{¤d7af00:"foobar"¤}{¤d70000: ¤}{¤d75fff:and¤}{¤d70000: ¤}{¤d75fd7:updates¤}{¤d70000: ¤}{¤d75fd7:$var¤}{¤d70000:                         ¤}{¤
   ¤}{¤d75fd7:$var¤}{¤d70000:                   ¤}{¤d7005f:#¤}{¤d70000: ¤}{¤d75fd7:will¤}{¤d70000: ¤}{¤d787d7:print¤}{¤d70000: ¤}{¤d7af00:"foobar"¤}{¤d70000:                                                    ¤}{¤

 ¤}{¤000003:Since the bang modifier makes a function modify the first argument, expressions like ¤}{¤000017: (append!¤}{¤000003:    ¤}{¤
 ¤}{¤000017:"foo" "bar") ¤}{¤000003: are not valid, as it's not clear where the intended side effect should go.          ¤}{¤

 ¤}{¤000003:The bang modifier can be used with path expressions to set deeper values:                         ¤}{¤

   ¤}{¤d75faf:(¤}{¤d75fd7:set!¤}{¤d70000: ¤}{¤d75fd7:$var¤}{¤d70000: ¤}{¤d75fd7:{foo¤}{¤d70000: ¤}{¤d7af00:"bar"¤}{¤d75fd7:}¤}{¤d75faf:)¤}{¤d70000: ¤}{¤d7005f:#¤}{¤d70000: ¤}{¤d75fd7:{¤}{¤d7af00:"foo"¤}{¤d7005f::¤}{¤d70000: ¤}{¤d7af00:"bar"¤}{¤d75fd7:}¤}{¤d70000:                                                        ¤}{¤
   ¤}{¤d75faf:(¤}{¤d75fd7:set!¤}{¤d70000: ¤}{¤d75fd7:$var.foo¤}{¤d70000: ¤}{¤d7af00:"new"¤}{¤d75faf:)¤}{¤d70000:   ¤}{¤d7005f:#¤}{¤d70000: ¤}{¤d7af00:"new"¤}{¤d70000:                                                                 ¤}{¤
   ¤}{¤d75fd7:$var¤}{¤d70000:                    ¤}{¤d7005f:#¤}{¤d70000: ¤}{¤d75fd7:{¤}{¤d7af00:"foo"¤}{¤d7005f::¤}{¤d70000: ¤}{¤d7af00:"new"¤}{¤d75fd7:}¤}{¤d70000:                                                        ¤}{¤
   ¤}{¤d70000:                                                                                                ¤}{¤
   ¤}{¤d75faf:(¤}{¤d75fd7:set!¤}{¤d70000: ¤}{¤d75fd7:$var¤}{¤d70000: ¤}{¤d75fd7:[1¤}{¤d70000: ¤}{¤d787ff:2¤}{¤d70000: ¤}{¤d75fd7:3]¤}{¤d75faf:)¤}{¤d70000:    ¤}{¤d7005f:#¤}{¤d70000: ¤}{¤d75fd7:[1¤}{¤d70000: ¤}{¤d787ff:2¤}{¤d70000: ¤}{¤d75fd7:3]¤}{¤d70000:                                                                ¤}{¤
   ¤}{¤d75faf:(¤}{¤d75fd7:append!¤}{¤d70000: ¤}{¤d75fd7:$var¤}{¤d70000: ¤}{¤d787ff:4¤}{¤d75faf:)¤}{¤d70000:       ¤}{¤d7005f:#¤}{¤d70000: ¤}{¤d787ff:4¤}{¤d70000:                                                                      ¤}{¤
   ¤}{¤d75faf:(¤}{¤d75fd7:set!¤}{¤d70000: ¤}{¤d75fd7:$var[3]¤}{¤d70000: ¤}{¤d787ff:5¤}{¤d75faf:)¤}{¤d70000:       ¤}{¤d7005f:#¤}{¤d70000: ¤}{¤d787ff:5¤}{¤d70000:                                                                      ¤}{¤
   ¤}{¤d75fd7:$var¤}{¤d70000:                   ¤}{¤d7005f:#¤}{¤d70000: ¤}{¤d75fd7:[1¤}{¤d70000: ¤}{¤d787ff:2¤}{¤d70000: ¤}{¤d787ff:3¤}{¤d70000: ¤}{¤d75fd7:5]¤}{¤d70000:                                                              ¤}{¤

 ¤}{¤000003:The bang modifier can be used with any function, though you will be hardpressed to find meaningful¤}{¤
 ¤}{¤000003:examples of ¤}{¤000017: (if! .path.expr 42) ¤}{¤000003: or ¤}{¤000017: (eq?! .path 42) ¤}{¤000003:.                                           ¤}{¤

 ¤}{¤000008:### Symbol¤}{¤

 ¤}{¤000003:Symbols are either variables or bare path expressions that reference the global document.         ¤}{¤

 ¤}{¤000009:#### Variables¤}{¤

 ¤}{¤000003:Rudi has support for runtime variables. A variable begins with the literal ¤}{¤000017: $ ¤}{¤000003:, followed by a case-¤}{¤
 ¤}{¤000003:sensitive name, like ¤}{¤000017: $myVar ¤}{¤000003:. Variables hold any of the possible data types.                     ¤}{¤

 ¤}{¤000003:Symbols are expressions and can therefore be used in most places:                                 ¤}{¤

   ¤}{¤d75faf:(¤}{¤d75fd7:add¤}{¤d70000: ¤}{¤d75fd7:$myVar¤}{¤d70000: ¤}{¤d787ff:5¤}{¤d75faf:)¤}{¤d70000:                                                                                  ¤}{¤
   ¤}{¤d75faf:(¤}{¤d75fd7:concat¤}{¤d70000: ¤}{¤d7af00:"foo"¤}{¤d70000: ¤}{¤d75fd7:[1¤}{¤d70000: ¤}{¤d75fd7:$var¤}{¤d70000: ¤}{¤d75fd7:2]¤}{¤d75faf:)¤}{¤d70000:                                                                       ¤}{¤
   ¤}{¤d75faf:(¤}{¤d75fd7:set!¤}{¤d70000: ¤}{¤d75fd7:$myVar¤}{¤d70000: ¤}{¤d75faf:(¤}{¤d787d7:+¤}{¤d70000: ¤}{¤d787ff:1¤}{¤d70000: ¤}{¤d787ff:4¤}{¤d75faf:))¤}{¤d70000:                                                                           ¤}{¤

 ¤}{¤000003:A path expression can follow a variable name, allowing easy access to sub fields:                 ¤}{¤

   ¤}{¤d75faf:(¤}{¤d75fd7:set!¤}{¤d70000: ¤}{¤d75fd7:$var¤}{¤d70000: ¤}{¤d75fd7:[1,¤}{¤d70000: ¤}{¤d787ff:2¤}{¤d75f87:,¤}{¤d70000: ¤}{¤d75fd7:3]¤}{¤d75faf:)¤}{¤d70000:                                                                           ¤}{¤
   ¤}{¤d75faf:(¤}{¤d787d7:print¤}{¤d70000: ¤}{¤d75fd7:$var[0]¤}{¤d75faf:)¤}{¤d70000:                                                                                 ¤}{¤
   ¤}{¤d70000:                                                                                                ¤}{¤
   ¤}{¤d75faf:(¤}{¤d75fd7:set!¤}{¤d70000: ¤}{¤d75fd7:$var¤}{¤d70000: ¤}{¤d75fd7:{foo¤}{¤d70000: ¤}{¤d75fd7:[1,¤}{¤d70000: ¤}{¤d787ff:2¤}{¤d75f87:,¤}{¤d70000: ¤}{¤d75fd7:{foo¤}{¤d70000: ¤}{¤d7af00:"bar"¤}{¤d75fd7:}]}¤}{¤d75faf:)¤}{¤d70000:                                                           ¤}{¤
   ¤}{¤d75faf:(¤}{¤d787d7:print¤}{¤d70000: ¤}{¤d75fd7:$var.foo[2].foo¤}{¤d75faf:)¤}{¤d70000:                                                                         ¤}{¤

 ¤}{¤000003:See further down for more details on path expressions.                                            ¤}{¤

 ¤}{¤000009:#### Global Document Access¤}{¤

 ¤}{¤000003:Rudi programs are meant to transform a document (usually an ¤}{¤000017: Object ¤}{¤000003:). To make it easy to access  ¤}{¤
 ¤}{¤000003:the document and sub fields within, you can reference the global document by a single dot (¤}{¤000017: . ¤}{¤000003:),  ¤}{¤
 ¤}{¤000003:optionally (and often) with a path expression on it, like ¤}{¤000017: .foo.bar ¤}{¤000003:. So ¤}{¤000017: .foo ¤}{¤000003: would reference   ¤}{¤
 ¤}{¤000003:the field ¤}{¤000017: "foo" ¤}{¤000003: in the global document, whereas ¤}{¤000017: $var.foo ¤}{¤000003: is the field ¤}{¤000017: "foo" ¤}{¤000003: in the variable ¤}{¤
 ¤}{¤000017:$var ¤}{¤000003:.                                                                                            ¤}{¤

 ¤}{¤000003:Suppose a JSON document like                                                                      ¤}{¤

   ¤}{¤d75faf:{¤}{¤d70000:                                                                                               ¤}{¤
   ¤}{¤d70000:   ¤}{¤d78700:"foo"¤}{¤d75faf::¤}{¤d70000: ¤}{¤d7af00:"bar"¤}{¤d75faf:,¤}{¤d70000:                                                                                ¤}{¤
   ¤}{¤d70000:   ¤}{¤d78700:"list"¤}{¤d75faf::¤}{¤d70000: ¤}{¤d75faf:[¤}{¤d787ff:1¤}{¤d75faf:,¤}{¤d70000: ¤}{¤d787ff:2¤}{¤d75faf:,¤}{¤d70000: ¤}{¤d787ff:3¤}{¤d75faf:]¤}{¤d70000:                                                                            ¤}{¤
   ¤}{¤d75faf:}¤}{¤d70000:                                                                                               ¤}{¤

 ¤}{¤000003:is being processed by an Rudi program, then you could write                                       ¤}{¤

   ¤}{¤d75f87:.¤}{¤d75fd7:foo¤}{¤d70000:                                                                                            ¤}{¤
   ¤}{¤d75f87:.¤}{¤d75fd7:list[1]¤}{¤d70000:                                                                                        ¤}{¤

 ¤}{¤000003:to first select ¤}{¤000017: "bar" ¤}{¤000003:, then ¤}{¤000017: 2 ¤}{¤000003:. Bare path expressions work like variables, you can do anything ¤}{¤
 ¤}{¤000003:you can do with variables, like:                                                                  ¤}{¤

   ¤}{¤d75faf:(¤}{¤d75fd7:append!¤}{¤d70000: ¤}{¤d75f87:.¤}{¤d78787:list¤}{¤d70000: ¤}{¤d787ff:4¤}{¤d75faf:)¤}{¤d70000:                                                                               ¤}{¤
   ¤}{¤d75faf:(¤}{¤d75fd7:to-upper!¤}{¤d70000: ¤}{¤d75f87:.¤}{¤d75fd7:foo¤}{¤d75faf:)¤}{¤d70000:                                                                                ¤}{¤

 ¤}{¤000009:#### Scopes¤}{¤

 ¤}{¤000003:Rudi is roughly function-scoped, like JavaScript: Once a variable is defined using ¤}{¤000017: set! ¤}{¤000003:, it is  ¤}{¤
 ¤}{¤000003:available for the rest of the current program (or user-defined function).                         ¤}{¤

 ¤}{¤00000a:##### Variables¤}{¤

 ¤}{¤000003:A statement like ¤}{¤000017: (set! $foo 42) (if (condition) (set! $foo 7)) ¤}{¤000003: would be equal to                ¤}{¤

   ¤}{¤d75fd7:foo¤}{¤d70000: ¤}{¤d75f87::=¤}{¤d70000: ¤}{¤d787ff:42¤}{¤d70000:                                                                                       ¤}{¤
   ¤}{¤d70000:                                                                                                ¤}{¤
   ¤}{¤d700d7:if¤}{¤d70000: ¤}{¤d75fd7:condition¤}{¤d70000: ¤}{¤d75faf:{¤}{¤d70000:                                                                                  ¤}{¤
   ¤}{¤d70000:  ¤}{¤d75fd7:foo¤}{¤d70000: ¤}{¤d75faf:=¤}{¤d70000: ¤}{¤d787ff:7¤}{¤d70000:                                                                                       ¤}{¤
   ¤}{¤d75faf:}¤}{¤d70000:                                                                                               ¤}{¤
   ¤}{¤d70000:                                                                                                ¤}{¤
   ¤}{¤d75fff:println¤}{¤d75faf:(¤}{¤d75fd7:foo¤}{¤d75faf:)¤}{¤d70000: ¤}{¤d70087:// prints 42                                                                       ¤}{¤

 ¤}{¤000003:in Go. However function-scoping means that a variable is actually defined one it was set and is   ¤}{¤
 ¤}{¤000003:then valid for all subsequent expressions, so                                                     ¤}{¤

   ¤}{¤d75faf:(¤}{¤d75fd7:set!¤}{¤d70000: ¤}{¤d75fd7:$var¤}{¤d70000: ¤}{¤d787ff:42¤}{¤d75faf:)¤}{¤d70000:                                                                                  ¤}{¤
   ¤}{¤d75faf:(¤}{¤d700d7:if¤}{¤d70000: ¤}{¤d75faf:(¤}{¤d75fd7:gt?¤}{¤d70000: ¤}{¤d75fd7:$var¤}{¤d70000: ¤}{¤d787ff:4¤}{¤d75faf:)¤}{¤d70000: ¤}{¤d75faf:(¤}{¤d75fd7:set!¤}{¤d70000: ¤}{¤d75fd7:$tooLarge¤}{¤d70000: ¤}{¤d75fd7:true¤}{¤d75faf:))¤}{¤d70000:                                                         ¤}{¤
   ¤}{¤d75fd7:$tooLarge¤}{¤d70000:                                                                                       ¤}{¤

 ¤}{¤000003:will yield ¤}{¤000017: true ¤}{¤000003:, since the ¤}{¤000017: $tooLarge ¤}{¤000003: variable is available even after ¤}{¤000017: if ¤}{¤000003: has finished.      ¤}{¤

 ¤}{¤00000a:##### User-Defined Functions¤}{¤

 ¤}{¤000003:Functions defined using ¤}{¤000017: func! ¤}{¤000003: form a sub-program. This means any scoped variable defined on the ¤}{¤
 ¤}{¤000003:outside is not visible inside the function, the following is therefore invalid:                   ¤}{¤

   ¤}{¤d75faf:(¤}{¤d75fd7:set!¤}{¤d70000: ¤}{¤d75fd7:$foo¤}{¤d75faf:)¤}{¤d70000:                                                                                     ¤}{¤
   ¤}{¤d75faf:(¤}{¤d75fd7:func!¤}{¤d70000: ¤}{¤d75fd7:do-stuff¤}{¤d70000: ¤}{¤d75fd7:[]¤}{¤d70000: ¤}{¤d75faf:(¤}{¤d787d7:+¤}{¤d70000: ¤}{¤d75fd7:$foo¤}{¤d70000: ¤}{¤d787ff:1¤}{¤d75faf:))¤}{¤d70000:                                                                  ¤}{¤
   ¤}{¤d75faf:(¤}{¤d75fd7:do-stuff¤}{¤d75faf:)¤}{¤d70000:                                                                                      ¤}{¤

 ¤}{¤000003:User-defined functions run in their own scope, where only the arguments and global variables are  ¤}{¤
 ¤}{¤000003:available (though new, function-scoped variables can of course be defined).                       ¤}{¤

 ¤}{¤00000a:##### Global Document¤}{¤

 ¤}{¤000003:The exception from this rule is the global document. As the name implies, it is meant to be global¤}{¤
 ¤}{¤000003:and to allow for effective, readable Rudi code, there is only one document and it can be modified ¤}{¤
 ¤}{¤000003:from anywhere.                                                                                    ¤}{¤

 ¤}{¤000003:If a Rudi program was loaded with                                                                 ¤}{¤

   ¤}{¤d75faf:{¤}{¤d70000:                                                                                               ¤}{¤
   ¤}{¤d70000:   ¤}{¤d78700:"foo"¤}{¤d75faf::¤}{¤d70000: ¤}{¤d7af00:"bar"¤}{¤d75faf:,¤}{¤d70000:                                                                                ¤}{¤
   ¤}{¤d70000:   ¤}{¤d78700:"list"¤}{¤d75faf::¤}{¤d70000: ¤}{¤d75faf:[¤}{¤d787ff:1¤}{¤d75faf:,¤}{¤d70000: ¤}{¤d787ff:2¤}{¤d75faf:,¤}{¤d70000: ¤}{¤d787ff:3¤}{¤d75faf:]¤}{¤d70000:                                                                            ¤}{¤
   ¤}{¤d75faf:}¤}{¤d70000:                                                                                               ¤}{¤

 ¤}{¤000003:then                                                                                              ¤}{¤

   ¤}{¤d75faf:(¤}{¤d700d7:if¤}{¤d70000: ¤}{¤d75fd7:true¤}{¤d70000: ¤}{¤d75faf:(¤}{¤d75fd7:set!¤}{¤d70000: ¤}{¤d75f87:.¤}{¤d75fd7:foo¤}{¤d70000: ¤}{¤d7af00:"new-value"¤}{¤d75faf:))¤}{¤d70000:    ¤}{¤d7005f:#¤}{¤d70000: ¤}{¤d7af00:"new-value"¤}{¤d70000:                                              ¤}{¤
   ¤}{¤d75f87:.¤}{¤d75fd7:foo¤}{¤d70000:                                 ¤}{¤d7005f:#¤}{¤d70000: ¤}{¤d7af00:"new-value"¤}{¤d70000:                                              ¤}{¤
   ¤}{¤d70000:                                                                                                ¤}{¤
   ¤}{¤d75faf:(¤}{¤d700d7:if¤}{¤d70000: ¤}{¤d75fd7:true¤}{¤d70000: ¤}{¤d75faf:(¤}{¤d75fd7:append!¤}{¤d70000: ¤}{¤d75f87:.¤}{¤d78787:list¤}{¤d70000: ¤}{¤d787ff:4¤}{¤d75faf:))¤}{¤d70000:    ¤}{¤d7005f:#¤}{¤d70000: ¤}{¤d787ff:4¤}{¤d70000:                                                              ¤}{¤
   ¤}{¤d75f87:.¤}{¤d78787:list¤}{¤d70000:                          ¤}{¤d7005f:#¤}{¤d70000: ¤}{¤d75fd7:[1¤}{¤d70000: ¤}{¤d787ff:2¤}{¤d70000: ¤}{¤d787ff:3¤}{¤d70000: ¤}{¤d75fd7:4]¤}{¤d70000:                                                      ¤}{¤

 ¤}{¤000008:### Path Expression¤}{¤

 ¤}{¤000003:Rudi implements simple JSONPath-like expressions to allow descending into deeply nested objects.  ¤}{¤
 ¤}{¤000003:Each path consists of a series of steps, with each step being either an object step (e.g. ¤}{¤000017: .foo ¤}{¤000003:) ¤}{¤
 ¤}{¤000003:or a vector step (e.g. ¤}{¤000017: [42] ¤}{¤000003:). Steps can be chained, like ¤}{¤000017: .foo[42].bar.sub[1][2] ¤}{¤000003:.              ¤}{¤

 ¤}{¤000003:Path steps can also be computed (¤}{¤000017: [(+ 1 42)] ¤}{¤000003:), which allows to use more complex expressions to   ¤}{¤
 ¤}{¤000003:form steps, like ¤}{¤000017: ["string.with.dot"] ¤}{¤000003: or even ¤}{¤000017: [$var.index] ¤}{¤000003:.                                    ¤}{¤

 ¤}{¤000003:There is one special case: Paths that start with a vector step on the global document: For a      ¤}{¤
 ¤}{¤000003:variable this would look like ¤}{¤000017: $var[42] ¤}{¤000003:, but for the global document this would be just ¤}{¤000017: [42] ¤}{¤000003:,  ¤}{¤
 ¤}{¤000003:which is indistinguishable from "a vector with 1 element, the number 42". To resolve this         ¤}{¤
 ¤}{¤000003:ambiguity, bare path expressions that start with a vector step must have a leading dot, like      ¤}{¤
 ¤}{¤000017:.[42] ¤}{¤000003:.                                                                                           ¤}{¤

 ¤}{¤000003:Path expressions must be traversable, or else an error is returned: Trying to descend with ¤}{¤000017: .foo ¤}{¤000003: ¤}{¤
 ¤}{¤000003:into a vector would result in an error, likewise using ¤}{¤000017: [3] ¤}{¤000003: to descend into a string is an error.¤}{¤
 ¤}{¤000003:Use the ¤}{¤000017: has? ¤}{¤000003: and ¤}{¤000017: try ¤}{¤000003: functions to deal with possibly misfitting path expressions.             ¤}{¤

 ¤}{¤000003:Path expressions can be used on                                                                   ¤}{¤

 ¤}{¤000004:• Symbols (¤}{¤000017: $var.foo ¤}{¤000004: or ¤}{¤000017: .document.key ¤}{¤000004:)                                                         ¤}{¤
 ¤}{¤000004:• Vector nodes (¤}{¤000017: [1 2 3][1] ¤}{¤000004:, first step of the path must be a vector step, i.e. ¤}{¤000017: [1 2].foo ¤}{¤000004: is   ¤}{¤
 ¤}{¤000004:invalid)                                                                                          ¤}{¤
 ¤}{¤000004:• Object nodes (¤}{¤000017: {foo "bar"}.foo ¤}{¤000004:, first step of the path must be an object step, i.e. ¤}{¤000017: {foo¤}{¤000004:      ¤}{¤
 ¤}{¤000017:"bar"}[0] ¤}{¤000004:                                                                                        ¤}{¤
 ¤}{¤000004:is invalid)                                                                                       ¤}{¤
 ¤}{¤000004:• Tuples (¤}{¤000017: (map $obj to-upper).key ¤}{¤000004:, requires that the tuple evaluated to a vector or object that ¤}{¤
 ¤}{¤000004:can be traversed, otherwise an error is returned (e.g. ¤}{¤000017: (+ 1 2).key ¤}{¤000004: is invalid))                 ¤}{¤

 ¤}{¤000003:The evaluated value of any of these expressions is always ¤}{¤00000d:with¤}{¤000003: the path expression applied, so for¤}{¤
 ¤}{¤000003:example in ¤}{¤000017: (+ (process $obj).userCount 32) ¤}{¤000003: the ¤}{¤000017: + ¤}{¤000003: function will see 2 arguments like ¤}{¤000017: (+¤}{¤000003:       ¤}{¤
 ¤}{¤000017:$userCount 32) ¤}{¤000003: because when processing the ¤}{¤000017: process ¤}{¤000003: tuple, the path expression on it is also    ¤}{¤
 ¤}{¤000003:evaluated already.                                                                                ¤}{¤

¤}