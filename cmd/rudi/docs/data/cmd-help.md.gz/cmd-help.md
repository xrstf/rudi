{¤
 ¤}{¤000006: The Rudi interpreter :) ¤}{¤

 ¤}{¤000003:Rudi is a command line interpreter for the Rudi programming language. Rudi can read multiple      ¤}{¤
 ¤}{¤000003:JSON/YAML files and then apply JSON paths or scripts to them. For quicker development, an         ¤}{¤
 ¤}{¤000003:interactive REPL is also available.                                                               ¤}{¤

 ¤}{¤000007:## Modes¤}{¤

 ¤}{¤000003:Rudi can run in one of two modes:                                                                 ¤}{¤

 ¤}{¤000004:• ¤}{¤00000e:Interactive Mode¤}{¤000004: is enabled by passing ¤}{¤000017: --interactive ¤}{¤000004: (or ¤}{¤000017: -i ¤}{¤000004:). This will                     ¤}{¤
 ¤}{¤000004:start a REPL session where Rudi scripts are read from stdin and evaluated                         ¤}{¤
 ¤}{¤000004:against the loaded files.                                                                         ¤}{¤
 ¤}{¤000004:• ¤}{¤00000e:Script Mode¤}{¤000004: is used the an Rudi script is passed either as the first                            ¤}{¤
 ¤}{¤000004:argument or read from a file defined by ¤}{¤000017: --script ¤}{¤000004:. In this mode Rudi will                        ¤}{¤
 ¤}{¤000004:run all statements from the script and print the resulting value, then it exits.Examples:         ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: rudi '.foo' myfile.json ¤}{¤000004:                                                                     ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: rudi '(set .foo "bar") (set .users 42) .' myfile.json ¤}{¤000004:                                       ¤}{¤
 ¤}{¤000004:  • ¤}{¤000017: rudi --script convert.rudi myfile.json ¤}{¤000004:                                                      ¤}{¤
 ¤}{¤000004:                                                                                                  ¤}{¤

 ¤}{¤000007:## File Handling¤}{¤

 ¤}{¤000003:The first loaded file is known as the "document". Its content is available via path expressions   ¤}{¤
 ¤}{¤000003:like ¤}{¤000017: .foo[0] ¤}{¤000003:. All loaded files are also available via the ¤}{¤000017: $files ¤}{¤000003: variable (i.e. ¤}{¤000017: . ¤}{¤000003: is the    ¤}{¤
 ¤}{¤000003:same as ¤}{¤000017: $files[0] ¤}{¤000003: for reading, but when writing data, there is a difference between both        ¤}{¤
 ¤}{¤000003:notations; refer to the docs for ¤}{¤000017: set ¤}{¤000003: for more information).                                     ¤}{¤

 ¤}{¤000007:## Help¤}{¤

 ¤}{¤000003:Help is available by using ¤}{¤000017: help ¤}{¤000003: as the first argument to Rudi. This can be followed by a topic, ¤}{¤
 ¤}{¤000003:like ¤}{¤000017: help language ¤}{¤000003: or a function name, like ¤}{¤000017: help map ¤}{¤000003:.                                         ¤}{¤

¤}